#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define main app_main
#include "../src/main.c"
#undef main

static void printUsage(const char *progName) {
    printf("Usage: %s [OPTIONS]\n", progName);
    printf("Complaint Handling System (CHS) — Automated Escalation Checker (Cron Utility)\n\n");
    printf("Options:\n");
    printf("  --check-now           Execute immediate 24-hour escalation check (default)\n");
    printf("  --ref-time <YYYY-MM-DD HH:MM:SS>  Simulate execution at specified timestamp\n");
    printf("  --reason <text>       Custom escalation audit note\n");
    printf("  --dry-run             Audit overdue complaints without writing changes\n");
    printf("  --help                Display this assistance message\n");
}

int main(int argc, char **argv) {
    time_t referenceTime = 0;
    const char *customReason = NULL;
    int dryRun = 0;

    for (int i = 1; i < argc; ++i) {
        if (strcmp(argv[i], "--help") == 0 || strcmp(argv[i], "-h") == 0) {
            printUsage(argv[0]);
            return 0;
        } else if (strcmp(argv[i], "--dry-run") == 0) {
            dryRun = 1;
        } else if (strcmp(argv[i], "--reason") == 0 && (i + 1 < argc)) {
            customReason = argv[++i];
        } else if (strcmp(argv[i], "--ref-time") == 0 && (i + 1 < argc)) {
            referenceTime = parseComplaintTimestamp(argv[++i]);
            if (referenceTime == (time_t)-1) {
                fprintf(stderr, "[ERROR] Invalid timestamp format for --ref-time. Expected: 'YYYY-MM-DD HH:MM:SS'\n");
                return 1;
            }
        }
    }

    int lockFd = acquireDataLock();
    if (lockFd < 0) {
        fprintf(stderr, "[CRON ERROR] Could not acquire storage lock. Another process is modifying data.\n");
        return 1;
    }

    /* Initialize system state from persistent files */
    initSystem();

    time_t checkTime = (referenceTime != 0) ? referenceTime : time(NULL);
    char checkTimeStr[26];
    formatComplaintTimestamp(checkTime, checkTimeStr, sizeof(checkTimeStr));

    printf("========================================================================\n");
    printf("   CHS AUTOMATED ESCALATION CHECKER (CRON)\n");
    printf("   Execution Reference Time: %s\n", checkTimeStr);
    if (dryRun) {
        printf("   MODE: DRY-RUN (no persistent modifications)\n");
    }
    printf("========================================================================\n");

    int overdueCount = 0;
    ComplaintNode *curr = complaintHead;
    while (curr != NULL) {
        if ((strcmp(curr->data.status, "RESOLVED") != 0) &&
            (strcmp(curr->data.status, "CLOSED") != 0) &&
            (strcmp(curr->data.status, "ESCALATED") != 0)) {
            time_t regTime = parseComplaintTimestamp(curr->data.timestamps.registered);
            if (regTime != (time_t)-1) {
                double elapsed = difftime(checkTime, regTime);
                if (elapsed >= (double)ESCALATION_THRESHOLD_SECONDS) {
                    overdueCount++;
                    printf(" [OVERDUE] ID: %s | Customer: %s | Registered: %s | Elapsed: %.1f hrs | Agent: %s\n",
                           curr->data.complaintId, curr->data.customerId,
                           curr->data.timestamps.registered,
                           elapsed / 3600.0, curr->data.assignedAgentId);
                }
            }
        }
        curr = curr->next;
    }

    if (overdueCount == 0) {
        printf("[INFO] Zero overdue complaints detected. All tickets within 24-hour SLA.\n");
    } else {
        if (!dryRun) {
            int escalated = checkAndEscalateComplaints(checkTime, customReason);
            printf("[SUCCESS] Automatically escalated %d complaint(s) to Manager.\n", escalated);
        } else {
            printf("[DRY-RUN] %d complaint(s) would be escalated.\n", overdueCount);
        }
    }

    freeAllMemory();
    releaseDataLock(lockFd);
    printf("========================================================================\n");
    return 0;
}
