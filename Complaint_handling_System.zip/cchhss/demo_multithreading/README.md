# Standalone Multithreading Demonstration (POSIX pthreads)

This folder contains an independent, educational C11 POSIX threads (`pthreads`) concurrency demonstration designed for technical evaluation and presentation.

> **CRITICAL ARCHITECTURAL ISOLATION RULE:**  
> This demonstration is strictly isolated from the production Complaint Handling System (`cchhss`). The production application remains strictly single-threaded with zero multithreading dependencies. This demonstration uses no complaint-system functions, headers, or data files.

---

## 1. Core Concurrency Concepts

### A. What is a Thread?
A **thread** (or thread of execution) is the smallest sequence of programmed instructions that can be managed independently by an operating system scheduler. 
- In a single-threaded process, instructions execute sequentially one after another.
- In a multithreaded process, multiple threads exist within the context of a single process, sharing the process's resources (such as virtual address space, heap memory, open file descriptors, and global variables), but each maintaining its own **call stack**, **program counter**, and **processor registers**.
- On modern multi-core processors, worker threads run in parallel across distinct CPU cores.

### B. Why Shared Data Creates Race Conditions
When multiple threads read and write to the same shared memory location concurrently without synchronization, a **race condition** (or data race) occurs.

Consider the increment operation on a shared variable:
```c
shared_counter++;
```
At the machine level, this single C statement translates to three discrete CPU instructions:
1. **LOAD:** Read the current value of `shared_counter` from memory into a CPU register.
2. **ADD:** Increment the register value by 1.
3. **STORE:** Write the updated register value back to memory.

If two threads (Thread A and Thread B) execute this simultaneously without protection:
1. Thread A loads `shared_counter` (value = 10).
2. Thread B preempts Thread A and loads `shared_counter` (value = 10).
3. Thread A increments register (value = 11) and stores 11.
4. Thread B increments register (value = 11) and stores 11.

Both threads performed an increment, but the counter only increased by 1 instead of 2. One update was silently lost. Over hundreds of thousands of iterations, this results in non-deterministic, corrupted data.

### C. What a Mutex Does
A **Mutex** (*Mutual Exclusion* lock, `pthread_mutex_t`) is a synchronization primitive used to protect shared data by serializing access to a **critical section**.
- Before entering the critical section, a thread calls `pthread_mutex_lock(&mutex)`. If another thread currently holds the lock, the calling thread is suspended (put to sleep by the OS scheduler) until the lock is released.
- Only one thread can hold the mutex lock at any given time.
- After finishing the critical section, the thread calls `pthread_mutex_unlock(&mutex)`, waking up a waiting thread.
- This ensures that the LOAD-ADD-STORE cycle is executed atomically with respect to other threads, guaranteeing data integrity.

### D. Why Joining Threads Matters
When a thread is spawned with `pthread_create()`, it runs asynchronously in the background. The parent thread must call `pthread_join(thread_id, NULL)`:
1. **Synchronization:** The parent thread waits (blocks) until the target thread has fully terminated its execution. Without `pthread_join()`, the main function could return and exit the process while worker threads are still executing, abnormally killing them mid-computation.
2. **Resource Reclamation:** Under POSIX standards, joinable threads that terminate retain their exit status and thread descriptors in kernel memory until joined. Failure to join created threads causes a thread descriptor leak (analogous to a zombie process).
3. **Safe Teardown:** Resources shared by the threads (such as the mutex itself) can only be safely destroyed (`pthread_mutex_destroy()`) *after* all threads using them have been joined and have finished execution.

---

## 2. Compilation and Execution on Linux

### A. Using the Project Makefile
From the project root directory, run:
```bash
# Build the standalone multithreading demo
make demo-threads

# Execute the demonstration
make run-threads
```

### B. Direct GCC Compilation
You can also compile and run the demo directly using GCC with the `-pthread` flag:
```bash
# Compile with C11, standard warnings, and POSIX threads
gcc -std=c11 -Wall -Wextra -Wpedantic -pthread -O2 -o demo_threads demo_multithreading/main.c

# Run the binary
./demo_threads
```

---

## 3. Thread-Safety Analysis with Valgrind Helgrind

**Helgrind** is a Valgrind tool designed to detect synchronization errors in C/C++ POSIX threads programs, such as data races, misuse of the POSIX pthreads API, and lock order violations (deadlocks).

### A. Running Helgrind via Makefile
```bash
make helgrind
```

### B. Running Helgrind Directly
```bash
# Build with debug symbols
gcc -std=c11 -Wall -Wextra -Wpedantic -pthread -g3 -O0 -o demo_threads_debug demo_multithreading/main.c

# Run under Valgrind Helgrind
valgrind --tool=helgrind --error-exitcode=1 ./demo_threads_debug
```

---

## 4. Expected Output and Interpretation

When executed, the program produces output similar to:
```text
======================================================================
          POSIX MULTITHREADING & SYNCHRONIZATION DEMO
======================================================================
[INFO] Number of worker threads : 4
[INFO] Increments per thread    : 100000
[INFO] Expected final counter   : 400000
----------------------------------------------------------------------
[INFO] Worker thread 1 created successfully (TID: 140442381227776).
[INFO] Worker thread 2 created successfully (TID: 140442372835072).
[INFO] Worker thread 3 created successfully (TID: 140442364442368).
[INFO] Worker thread 4 created successfully (TID: 140442356049664).
[INFO] Worker thread 1 joined successfully.
[INFO] Worker thread 2 joined successfully.
[INFO] Worker thread 3 joined successfully.
[INFO] Worker thread 4 joined successfully.
----------------------------------------------------------------------
 Expected Counter : 400000
 Actual Counter   : 400000
 Threads Created  : 4 of 4
 Join Errors      : 0
----------------------------------------------------------------------
 [SUCCESS] Thread safety verified! Zero race conditions detected.
======================================================================
```

### How to Interpret the Output:
- **Threads Created (4 of 4):** Confirms that all 4 POSIX worker threads were successfully allocated and spawned by the operating system kernel.
- **Join Status:** Confirms that each worker thread completed its 100,000 iterations and terminated cleanly without returning error codes.
- **Actual Counter = 400,000:** Confirms that the `pthread_mutex` completely eliminated race conditions across the 4 concurrent threads. Every single one of the 400,000 increments was atomically registered.
- **Helgrind Summary (`0 errors from 0 contexts`):** Verifies that the implementation contains zero data races, proper lock ordering, and correct POSIX thread resource reclamation.
