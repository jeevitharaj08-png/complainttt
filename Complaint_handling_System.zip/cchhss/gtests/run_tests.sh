#!/usr/bin/env bash
set -e

# ==============================================================================
# Linux Test Runner for Complaint Handling System Google Test Suite
# ==============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

echo "========================================================================"
echo "          HCL Linux Test Suite: Complaint Handling System"
echo "========================================================================"

# 1. Verify required Linux build and test tools
REQUIRED_TOOLS=("gcc" "g++" "cmake" "make")
for tool in "${REQUIRED_TOOLS[@]}"; do
    if ! command -v "${tool}" >/dev/null 2>&1; then
        echo "[ERROR] Required Linux tool '${tool}' is not installed or not in PATH." >&2
        exit 1
    fi
done

echo "[INFO] Environment verified: Linux $(uname -s) $(uname -r) on $(uname -m)"
echo "[INFO] GCC version: $(gcc --version | head -n 1)"
echo "[INFO] G++ version: $(g++ --version | head -n 1)"
echo "[INFO] CMake version: $(cmake --version | head -n 1)"

# 2. Setup build directory
BUILD_DIR="${SCRIPT_DIR}/build"
mkdir -p "${BUILD_DIR}"
cd "${BUILD_DIR}"

# 3. Configure using CMake
echo "[INFO] Configuring test suite with CMake..."
cmake "${SCRIPT_DIR}" -DCMAKE_BUILD_TYPE=Debug

# 4. Build GTest executable
echo "[INFO] Building Google Test executable..."
make -j"$(nproc)"

# 5. Run the complete test suite
echo "========================================================================"
echo "                   Running Google Test Suite"
echo "========================================================================"
./run_unit_tests --gtest_color=yes

TEST_STATUS=$?
if [ ${TEST_STATUS} -eq 0 ]; then
    echo "========================================================================"
    echo " [SUCCESS] All unit tests passed cleanly."
    echo "========================================================================"
else
    echo "========================================================================"
    echo " [FAILURE] One or more unit tests failed." >&2
    echo "========================================================================"
    exit ${TEST_STATUS}
fi
