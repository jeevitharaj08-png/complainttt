#include "test_helpers.h"

class AuthenticationTest : public ::testing::Test {
protected:
    ScopedSandbox sandbox;

    void SetUp() override {
        initSystem();
    }

    void TearDown() override {
        freeAllMemory();
    }
};

/* ========================================================================= */
/* FUNCTION 13: customerLogin Tests                                          */
/* ========================================================================= */

TEST_F(AuthenticationTest, CustomerLogin_Successful) {
    freeAllMemory();
    sandbox.writeFile("data/customers.txt", "CUST1001|John Doe|johndoe|pass123|john@example.com\n");
    initSystem();

    // Login with valid credentials then logout from dashboard (choice 5)
    StdioCapture capture("johndoe\npass123\n5\n");
    customerLogin();

    std::string out = capture.getOutput();
    EXPECT_NE(out.find("Welcome back, John Doe!"), std::string::npos);
    EXPECT_NE(out.find("CUSTOMER DASHBOARD"), std::string::npos);
    EXPECT_NE(out.find("Logging out of customer session"), std::string::npos);
}

TEST_F(AuthenticationTest, CustomerLogin_InvalidCredentials) {
    freeAllMemory();
    sandbox.writeFile("data/customers.txt", "CUST1001|John Doe|johndoe|pass123|john@example.com\n");
    initSystem();

    // Case 1: Non-existent username
    {
        StdioCapture capture("nosuchuser\nanypass\n");
        customerLogin();
        EXPECT_NE(capture.getOutput().find("Authentication failed: Invalid username or password."), std::string::npos);
    }
    // Case 2: Existing username but incorrect password
    {
        StdioCapture capture("johndoe\nwrongpassword\n");
        customerLogin();
        EXPECT_NE(capture.getOutput().find("Authentication failed: Invalid username or password."), std::string::npos);
    }
}

/* ========================================================================= */
/* FUNCTION 19: agentMenu Tests                                              */
/* ========================================================================= */

TEST_F(AuthenticationTest, AgentMenu_ReturnDirectly) {
    StdioCapture capture("2\n"); // Choice 2: Return to main menu
    agentMenu();

    std::string out = capture.getOutput();
    EXPECT_NE(out.find("AGENT PORTAL"), std::string::npos);
}

TEST_F(AuthenticationTest, AgentMenu_CredentialValidationAndInactiveCheck) {
    // 1. Wrong password for active agent
    {
        StdioCapture capture("1\nagent1\nwrongpass\n2\n");
        agentMenu();
        EXPECT_NE(capture.getOutput().find("Authentication failed: Invalid agent username or password."), std::string::npos);
    }
    // 2. Inactive agent account access denied
    {
        freeAllMemory();
        sandbox.writeFile("data/agents.txt",
            "AGT101|Alice Smith|agent1|agentpass1|0|0\n"
            "AGT102|Bob Johnson|agent2|agentpass2|1|0\n");
        initSystem();

        StdioCapture capture("1\nagent1\nagentpass1\n2\n");
        agentMenu();
        EXPECT_NE(capture.getOutput().find("Access denied: Your agent account is currently set to Inactive."), std::string::npos);
    }
}

TEST_F(AuthenticationTest, AgentMenu_SuccessfulLoginAndLogout) {
    freeAllMemory();
    sandbox.writeFile("data/agents.txt",
        "AGT101|Alice Smith|agent1|agentpass1|1|0\n"
        "AGT102|Bob Johnson|agent2|agentpass2|1|0\n");
    initSystem();

    // Choice 1: Login, agent1, agentpass1, Choice 4 (Logout dashboard), Choice 2 (Return)
    StdioCapture capture("1\nagent1\nagentpass1\n4\n2\n");
    agentMenu();

    std::string out = capture.getOutput();
    EXPECT_NE(out.find("Welcome, Alice Smith (AGT101)!"), std::string::npos);
    EXPECT_NE(out.find("AGENT DASHBOARD"), std::string::npos);
    EXPECT_NE(out.find("Logging out of agent portal"), std::string::npos);
}

/* ========================================================================= */
/* FUNCTION 23: managerMenu Tests                                            */
/* ========================================================================= */

TEST_F(AuthenticationTest, ManagerMenu_ReturnDirectly) {
    StdioCapture capture("2\n"); // Choice 2: Return to main menu
    managerMenu();

    std::string out = capture.getOutput();
    EXPECT_NE(out.find("MANAGER PORTAL"), std::string::npos);
}

TEST_F(AuthenticationTest, ManagerMenu_CredentialValidation) {
    // 1. Invalid username
    {
        StdioCapture capture("1\nwrongadmin\nwrongpass\n2\n");
        managerMenu();
        EXPECT_NE(capture.getOutput().find("Authentication failed: Invalid manager credentials."), std::string::npos);
    }
    // 2. Valid user with wrong password
    {
        StdioCapture capture("1\nmanager\nwrongpass\n2\n");
        managerMenu();
        EXPECT_NE(capture.getOutput().find("Authentication failed: Invalid manager credentials."), std::string::npos);
    }
}

TEST_F(AuthenticationTest, ManagerMenu_SuccessfulLoginAndLogout) {
    // Choice 1 (Login), manager, manager123, Choice 6 (Logout of dashboard), Choice 2 (Return)
    StdioCapture capture("1\nmanager\nmanager123\n6\n2\n");
    managerMenu();

    std::string out = capture.getOutput();
    EXPECT_NE(out.find("Welcome, Operations Manager!"), std::string::npos);
    EXPECT_NE(out.find("MANAGER DASHBOARD"), std::string::npos);
    EXPECT_NE(out.find("Logging out of manager session"), std::string::npos);
}
