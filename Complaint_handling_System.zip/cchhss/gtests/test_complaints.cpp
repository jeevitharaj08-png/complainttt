#include "test_helpers.h"

class ComplaintsTest : public ::testing::Test {
protected:
    ScopedSandbox sandbox;

    void SetUp() override {
        initSystem();
    }

    void TearDown() override {
        freeAllMemory();
    }
};

/* ========================================================================= */
/* FUNCTION 5: findComplaintById Tests                                       */
/* ========================================================================= */

TEST_F(ComplaintsTest, FindComplaintById_NullOrEmpty) {
    EXPECT_EQ(findComplaintById(NULL), nullptr);
    EXPECT_EQ(findComplaintById(""), nullptr);
}

TEST_F(ComplaintsTest, FindComplaintById_EmptyList) {
    freeAllMemory();
    EXPECT_EQ(findComplaintById("CMP101"), nullptr);
}

TEST_F(ComplaintsTest, FindComplaintById_MultiNodeListTraversal) {
    freeAllMemory();
    sandbox.writeFile("data/complaints.txt",
        "CMP101|CUST1001|Technical Support|High|ASSIGNED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|First\n"
        "CMP102|CUST1001|Billing and Account|Medium|IN_PROGRESS|AGT102|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|Second\n"
        "CMP103|CUST1001|Customer Service|Low|RESOLVED|AGT103|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 11:00:00|N/A|N/A|Note|Third\n");
    initSystem();

    ComplaintNode *head = findComplaintById("CMP101");
    ASSERT_NE(head, nullptr);
    EXPECT_STREQ(head->data.complaintId, "CMP101");

    ComplaintNode *mid = findComplaintById("CMP102");
    ASSERT_NE(mid, nullptr);
    EXPECT_STREQ(mid->data.complaintId, "CMP102");

    ComplaintNode *tail = findComplaintById("CMP103");
    ASSERT_NE(tail, nullptr);
    EXPECT_STREQ(tail->data.complaintId, "CMP103");

    ComplaintNode *missing = findComplaintById("CMP999");
    EXPECT_EQ(missing, nullptr);
}

/* ========================================================================= */
/* FUNCTION 6: addAuditEntry Tests                                           */
/* ========================================================================= */

TEST_F(ComplaintsTest, AddAuditEntry_NullSafetyAndFallbacks) {
    // 1. Null node: must safely return without crashing
    addAuditEntry(NULL, "ACTION", "BY", "Details");

    freeAllMemory();
    sandbox.writeFile("data/complaints.txt",
        "CMP101|CUST1001|Technical Support|High|ASSIGNED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|Desc\n");
    initSystem();

    ComplaintNode *node = findComplaintById("CMP101");
    ASSERT_NE(node, nullptr);

    // 2. Pass NULL arguments to exercise fallback branches ("ACTION", "SYSTEM", "")
    addAuditEntry(node, NULL, NULL, NULL);
    ASSERT_NE(node->auditHead, nullptr);
    EXPECT_STREQ(node->auditHead->action, "ACTION");
    EXPECT_STREQ(node->auditHead->performedBy, "SYSTEM");
    EXPECT_STREQ(node->auditHead->details, "");
}

TEST_F(ComplaintsTest, AddAuditEntry_MultiNodeAppends) {
    freeAllMemory();
    sandbox.writeFile("data/complaints.txt",
        "CMP101|CUST1001|Technical Support|High|ASSIGNED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|Desc\n");
    initSystem();

    ComplaintNode *node = findComplaintById("CMP101");
    ASSERT_NE(node, nullptr);

    // 1st entry: auditHead == NULL
    addAuditEntry(node, "CREATED", "CUST1001", "Ticket logged");
    ASSERT_NE(node->auditHead, nullptr);
    EXPECT_STREQ(node->auditHead->action, "CREATED");
    EXPECT_STREQ(node->auditHead->performedBy, "CUST1001");
    EXPECT_STREQ(node->auditHead->details, "Ticket logged");

    // 2nd entry: loops to tail
    addAuditEntry(node, "ASSIGNED", "SYSTEM", "Assigned to AGT101");
    ASSERT_NE(node->auditHead->next, nullptr);
    EXPECT_STREQ(node->auditHead->next->action, "ASSIGNED");

    // 3rd entry: loops past second
    addAuditEntry(node, "PROGRESS", "AGT101", "Investigating issue");
    AuditNode *third = node->auditHead->next->next;
    ASSERT_NE(third, nullptr);
    EXPECT_STREQ(third->action, "PROGRESS");
}

TEST_F(ComplaintsTest, AddAuditEntry_MemoryAllocationFailure) {
    freeAllMemory();
    sandbox.writeFile("data/complaints.txt",
        "CMP101|CUST1001|Technical Support|High|ASSIGNED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|Desc\n");
    initSystem();

    ComplaintNode *node = findComplaintById("CMP101");
    ASSERT_NE(node, nullptr);

    StdioCapture capture;
    FailMallocGuard guard;
    addAuditEntry(node, "FAIL_ACTION", "TESTER", "Fail");
    EXPECT_NE(capture.getOutput().find("Error: Memory allocation failed for audit entry"), std::string::npos);
}

/* ========================================================================= */
/* FUNCTION 7: autoAssignAgent Tests                                         */
/* ========================================================================= */

TEST_F(ComplaintsTest, AutoAssignAgent_EqualWorkloadAndAllInactive) {
    // 1. Equal workload (0 complaints) -> AGT101 (index 0) selected
    EXPECT_EQ(autoAssignAgent(), 0);

    // 2. All 10 agents inactive -> returns -1
    freeAllMemory();
    std::string inactiveAgents;
    for (int i = 0; i < MAX_AGENTS; i++) {
        char buf[128];
        snprintf(buf, sizeof(buf), "AGT%03d|Agent %d|user%d|pass%d|0|0\n", 101 + i, i + 1, i + 1, i + 1);
        inactiveAgents += buf;
    }
    sandbox.writeFile("data/agents.txt", inactiveAgents);
    initSystem();

    EXPECT_EQ(autoAssignAgent(), -1);
}

TEST_F(ComplaintsTest, AutoAssignAgent_SelectsLeastOpenWorkload) {
    freeAllMemory();
    sandbox.writeFile("data/complaints.txt",
        "CMP101|CUST1001|Technical Support|High|ASSIGNED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|1\n"
        "CMP102|CUST1001|Technical Support|High|IN_PROGRESS|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|2\n"
        "CMP103|CUST1001|Technical Support|High|ASSIGNED|AGT102|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|3\n"
        "CMP104|CUST1001|Technical Support|High|RESOLVED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 11:00:00|N/A|N/A|Note|4\n"
        "CMP105|CUST1001|Technical Support|High|CLOSED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 11:00:00|2026-01-01 12:00:00|N/A|Note|5\n");

    std::string agentsContent =
        "AGT101|Alice|agent1|pass1|1|0\n"
        "AGT102|Bob|agent2|pass2|1|0\n"
        "AGT103|Charlie|agent3|pass3|0|0\n";
    for (int i = 3; i < MAX_AGENTS; i++) {
        char buf[128];
        snprintf(buf, sizeof(buf), "AGT%03d|Agent %d|user%d|pass%d|0|0\n", 101 + i, i + 1, i + 1, i + 1);
        agentsContent += buf;
    }
    sandbox.writeFile("data/agents.txt", agentsContent);
    initSystem();

    // AGT101 has 2 open, AGT102 has 1 open -> AGT102 (idx 1) selected
    EXPECT_EQ(autoAssignAgent(), 1);
}

/* ========================================================================= */
/* FUNCTION 15: customerRegisterComplaint Tests                             */
/* ========================================================================= */

TEST_F(ComplaintsTest, CustomerRegisterComplaint_EmptyDescriptionAndMallocFailure) {
    // 1. Empty description aborts
    {
        StdioCapture capture("1\n2\n\n");
        customerRegisterComplaint("CUST1001");
        EXPECT_NE(capture.getOutput().find("Registration aborted: Description cannot be empty"), std::string::npos);
        EXPECT_EQ(findComplaintById("CMP101"), nullptr);
    }
    // 2. Malloc failure aborts
    {
        FailMallocGuard guard;
        StdioCapture capture("1\n1\nWill fail malloc\n");
        customerRegisterComplaint("CUST1001");
        EXPECT_NE(capture.getOutput().find("Error: Memory allocation failed"), std::string::npos);
    }
}

TEST_F(ComplaintsTest, CustomerRegisterComplaint_ActiveAssignmentAndListGrowth) {
    // 1. Register first complaint with active agent
    {
        StdioCapture capture("1\n1\nSystem not starting\n");
        customerRegisterComplaint("CUST1001");
        std::string out = capture.getOutput();
        EXPECT_NE(out.find("Complaint Registered Successfully"), std::string::npos);
        EXPECT_NE(out.find("CMP101"), std::string::npos);
        EXPECT_NE(out.find("ASSIGNED"), std::string::npos);

        ComplaintNode *node = findComplaintById("CMP101");
        ASSERT_NE(node, nullptr);
        EXPECT_STREQ(node->data.customerId, "CUST1001");
        EXPECT_STREQ(node->data.status, "ASSIGNED");
        EXPECT_STREQ(node->data.assignedAgentId, "AGT101");
        ASSERT_NE(node->auditHead, nullptr);
        EXPECT_STREQ(node->auditHead->action, "REGISTERED");
    }

    // 2. Collision avoidance loop test
    {
        ComplaintNode *c1 = findComplaintById("CMP101");
        ASSERT_NE(c1, nullptr);
        strcpy(c1->data.complaintId, "CMP102");

        StdioCapture capture("1\n1\nCollision trigger complaint\n");
        customerRegisterComplaint("CUST1001");

        ComplaintNode *newNode = findComplaintById("CMP103");
        ASSERT_NE(newNode, nullptr);
        EXPECT_STREQ(newNode->data.complaintId, "CMP103");
        strcpy(c1->data.complaintId, "CMP101"); // Restore
    }

    // 3. Append to existing complaint list (curr = curr->next)
    {
        StdioCapture capture("2\n2\nAnother complaint\n");
        customerRegisterComplaint("CUST1001");
    }
}

TEST_F(ComplaintsTest, CustomerRegisterComplaint_InactiveAgentsFallback) {
    // Set all agents to inactive
    std::string inactive;
    for (int i = 0; i < MAX_AGENTS; i++) {
        char buf[128];
        snprintf(buf, sizeof(buf), "AGT%03d|Agent %d|user%d|pass%d|0|0\n", 101 + i, i + 1, i + 1, i + 1);
        inactive += buf;
    }
    sandbox.writeFile("data/agents.txt", inactive);
    freeAllMemory();
    initSystem();

    StdioCapture capture("2\n3\nBilling discrepancy\n");
    customerRegisterComplaint("CUST1001");
    std::string out = capture.getOutput();
    EXPECT_NE(out.find("Assigned Agent:     Pending Manager Assignment"), std::string::npos);

    ComplaintNode *node = findComplaintById("CMP101");
    ASSERT_NE(node, nullptr);
    EXPECT_STREQ(node->data.status, "PENDING");
    EXPECT_STREQ(node->data.assignedAgentId, "UNASSIGNED");
}
