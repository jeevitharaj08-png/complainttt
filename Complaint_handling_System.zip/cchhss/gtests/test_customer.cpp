#include "test_helpers.h"

class CustomerTest : public ::testing::Test {
protected:
    ScopedSandbox sandbox;

    void SetUp() override {
        initSystem();
    }

    void TearDown() override {
        freeAllMemory();
    }
};

/* ========================================================================= */
/* FUNCTION 4: findCustomerByUsername Tests                                  */
/* ========================================================================= */

TEST_F(CustomerTest, FindCustomerByUsername_NullOrEmpty) {
    EXPECT_EQ(findCustomerByUsername(NULL), nullptr);
    EXPECT_EQ(findCustomerByUsername(""), nullptr);
}

TEST_F(CustomerTest, FindCustomerByUsername_EmptyList) {
    freeAllMemory();
    EXPECT_EQ(findCustomerByUsername("johndoe"), nullptr);
}

TEST_F(CustomerTest, FindCustomerByUsername_MultiNodeListTraversal) {
    freeAllMemory();
    sandbox.writeFile("data/customers.txt",
        "CUST1001|Alice First|alice|pass1|contact1\n"
        "CUST1002|Bob Middle|bob|pass2|contact2\n"
        "CUST1003|Charlie Last|charlie|pass3|contact3\n");
    initSystem();

    // Head match
    CustomerNode *headNode = findCustomerByUsername("alice");
    ASSERT_NE(headNode, nullptr);
    EXPECT_STREQ(headNode->data.fullName, "Alice First");

    // Middle match
    CustomerNode *midNode = findCustomerByUsername("bob");
    ASSERT_NE(midNode, nullptr);
    EXPECT_STREQ(midNode->data.fullName, "Bob Middle");

    // Tail match
    CustomerNode *tailNode = findCustomerByUsername("charlie");
    ASSERT_NE(tailNode, nullptr);
    EXPECT_STREQ(tailNode->data.fullName, "Charlie Last");

    // Not found after traversal
    CustomerNode *missingNode = findCustomerByUsername("david");
    EXPECT_EQ(missingNode, nullptr);
}

/* ========================================================================= */
/* FUNCTION 11: customerMenu Tests                                           */
/* ========================================================================= */

TEST_F(CustomerTest, CustomerMenu_ReturnDirectly) {
    StdioCapture capture("3\n"); // Choice 3: Return to main menu
    customerMenu();

    std::string out = capture.getOutput();
    EXPECT_NE(out.find("CUSTOMER PORTAL"), std::string::npos);
}

TEST_F(CustomerTest, CustomerMenu_NavigateRegisterAndLoginThenReturn) {
    // 1. Choice 1 (Register) with blank name to abort, then Choice 3
    {
        StdioCapture capture("1\n\n3\n");
        customerMenu();
        std::string out = capture.getOutput();
        EXPECT_NE(out.find("Customer Account Registration"), std::string::npos);
        EXPECT_NE(out.find("Registration cancelled: Full name cannot be blank"), std::string::npos);
    }
    // 2. Choice 2 (Login) with invalid credentials, then Choice 3
    {
        StdioCapture capture("2\nnouser\nnopass\n3\n");
        customerMenu();
        std::string out = capture.getOutput();
        EXPECT_NE(out.find("Customer Login"), std::string::npos);
        EXPECT_NE(out.find("Authentication failed"), std::string::npos);
    }
}

/* ========================================================================= */
/* FUNCTION 12: customerRegister Tests                                       */
/* ========================================================================= */

TEST_F(CustomerTest, CustomerRegister_MandatoryFieldValidation) {
    // Blank full name
    {
        StdioCapture capture("\n");
        customerRegister();
        EXPECT_NE(capture.getOutput().find("Full name cannot be blank"), std::string::npos);
    }
    // Blank username
    {
        StdioCapture capture("John Doe\n\n");
        customerRegister();
        EXPECT_NE(capture.getOutput().find("Username cannot be blank"), std::string::npos);
    }
    // Blank password
    {
        StdioCapture capture("John Doe\nnewuser\n\n");
        customerRegister();
        EXPECT_NE(capture.getOutput().find("Password cannot be blank"), std::string::npos);
    }
    // Blank contact
    {
        StdioCapture capture("John Doe\nnewuser\npass123\n\n");
        customerRegister();
        EXPECT_NE(capture.getOutput().find("Contact details cannot be blank"), std::string::npos);
    }
}

TEST_F(CustomerTest, CustomerRegister_DuplicateUsernameAborts) {
    freeAllMemory();
    sandbox.writeFile("data/customers.txt", "CUST1001|John Doe|johndoe|pass123|contact\n");
    initSystem();

    StdioCapture capture("Another Name\njohndoe\n");
    customerRegister();
    EXPECT_NE(capture.getOutput().find("already taken"), std::string::npos);
}

TEST_F(CustomerTest, CustomerRegister_SuccessfulRegistrationAndListAppends) {
    // 1. First customer (head node)
    {
        StdioCapture capture("First User\nfirstuser\npass1\ncontact1@test.com\n");
        customerRegister();
        EXPECT_NE(capture.getOutput().find("Account created successfully"), std::string::npos);
        EXPECT_NE(capture.getOutput().find("CUST1001"), std::string::npos);
    }
    // 2. Second customer (appended to head)
    {
        StdioCapture capture("Second User\nseconduser\npass2\ncontact2@test.com\n");
        customerRegister();
        EXPECT_NE(capture.getOutput().find("Account created successfully"), std::string::npos);
        EXPECT_NE(capture.getOutput().find("CUST1002"), std::string::npos);
    }
    // 3. Third customer (traverses curr = curr->next)
    {
        StdioCapture capture("Third User\nthirduser\npass3\ncontact3@test.com\n");
        customerRegister();
        EXPECT_NE(capture.getOutput().find("Account created successfully"), std::string::npos);
        EXPECT_NE(capture.getOutput().find("CUST1003"), std::string::npos);
    }

    CustomerNode *node1 = findCustomerByUsername("firstuser");
    CustomerNode *node2 = findCustomerByUsername("seconduser");
    CustomerNode *node3 = findCustomerByUsername("thirduser");
    ASSERT_NE(node1, nullptr);
    ASSERT_NE(node2, nullptr);
    ASSERT_NE(node3, nullptr);
    EXPECT_STREQ(node1->data.customerId, "CUST1001");
    EXPECT_STREQ(node2->data.customerId, "CUST1002");
    EXPECT_STREQ(node3->data.customerId, "CUST1003");
}

TEST_F(CustomerTest, CustomerRegister_MemoryAllocationFailure) {
    FailMallocGuard guard;
    StdioCapture capture("Fail User\nfailuser\npass\ncontact\n");
    customerRegister();
    EXPECT_NE(capture.getOutput().find("Error: System memory allocation failed"), std::string::npos);
}

/* ========================================================================= */
/* FUNCTION 14: customerDashboard Tests                                      */
/* ========================================================================= */

TEST_F(CustomerTest, CustomerDashboard_DispatchSubFunctionsAndLogout) {
    // Dispatches: 1 (lodge complaint, abort via empty desc), 2 (view complaints),
    // 3 (track missing), 4 (view missing history), 5 (logout)
    StdioCapture capture("1\n1\n1\n\n2\n3\nCMP999\n4\nCMP999\n5\n");
    customerDashboard("CUST1001", "John Doe");

    std::string out = capture.getOutput();
    EXPECT_NE(out.find("CUSTOMER DASHBOARD: John Doe (CUST1001)"), std::string::npos);
    EXPECT_NE(out.find("Register a New Complaint"), std::string::npos);
    EXPECT_NE(out.find("My Registered Complaints"), std::string::npos);
    EXPECT_NE(out.find("Enter Complaint ID to track"), std::string::npos);
    EXPECT_NE(out.find("Enter Complaint ID for audit history"), std::string::npos);
    EXPECT_NE(out.find("Logging out of customer session"), std::string::npos);
}

/* ========================================================================= */
/* FUNCTION 16: customerViewComplaints Tests                                 */
/* ========================================================================= */

TEST_F(CustomerTest, CustomerViewComplaints_ZeroAndMultiple) {
    // 1. Zero complaints
    {
        StdioCapture capture;
        customerViewComplaints("CUST1001");
        EXPECT_NE(capture.getOutput().find("No complaints found under your account"), std::string::npos);
    }
    // 2. Multiple complaints with customer isolation
    {
        freeAllMemory();
        sandbox.writeFile("data/complaints.txt",
            "CMP101|CUST1001|Technical Support|High|ASSIGNED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|Description 101\n"
            "CMP102|CUST1002|Billing and Account|Low|PENDING|UNASSIGNED|2026-01-01 11:00:00|N/A|2026-01-01 11:00:00|N/A|N/A|N/A|Note|Description 102\n");
        initSystem();

        StdioCapture capture;
        customerViewComplaints("CUST1001");
        std::string out = capture.getOutput();
        EXPECT_NE(out.find("CMP101"), std::string::npos);
        EXPECT_EQ(out.find("CMP102"), std::string::npos);
        EXPECT_NE(out.find("Total Complaints: 1"), std::string::npos);
    }
}

/* ========================================================================= */
/* FUNCTION 17: customerTrackComplaint Tests                                 */
/* ========================================================================= */

TEST_F(CustomerTest, CustomerTrackComplaint_NotFoundAndSecurityViolation) {
    // 1. Complaint not found
    {
        StdioCapture capture("CMP999\n");
        customerTrackComplaint("CUST1001");
        EXPECT_NE(capture.getOutput().find("Error: Complaint ID 'CMP999' not found"), std::string::npos);
    }
    // 2. Security violation (attempting to track another customer's complaint)
    {
        freeAllMemory();
        sandbox.writeFile("data/complaints.txt",
            "CMP101|CUST1002|Technical Support|High|ASSIGNED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|Desc\n");
        initSystem();

        StdioCapture capture("CMP101\n");
        customerTrackComplaint("CUST1001");
        EXPECT_NE(capture.getOutput().find("Security violation: You are not authorized to view complaints"), std::string::npos);
    }
}

TEST_F(CustomerTest, CustomerTrackComplaint_AllStagesProgression) {
    freeAllMemory();
    sandbox.writeFile("data/complaints.txt",
        "CMP101|CUST1001|Technical Support|High|PENDING|UNASSIGNED|2026-01-01 10:00:00|N/A|2026-01-01 10:00:00|N/A|N/A|N/A|Note|Desc\n"
        "CMP102|CUST1001|Technical Support|High|ASSIGNED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|Desc\n"
        "CMP103|CUST1001|Technical Support|High|IN_PROGRESS|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|Desc\n"
        "CMP104|CUST1001|Technical Support|High|ESCALATED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|Desc\n"
        "CMP105|CUST1001|Technical Support|High|RESOLVED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 11:00:00|N/A|N/A|Note|Desc\n"
        "CMP106|CUST1001|Technical Support|High|CLOSED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 11:00:00|2026-01-01 12:00:00|N/A|Note|Desc\n"
        "CMP107|CUST1001|Technical Support|High|CUSTOM_STATUS|AGT101|2026-01-01 10:00:00|N/A|2026-01-01 10:00:00|N/A|N/A|N/A|Note|Desc\n");
    initSystem();

    for (int i = 1; i <= 7; i++) {
        char idBuf[16];
        snprintf(idBuf, sizeof(idBuf), "CMP10%d\n", i);
        StdioCapture c(idBuf);
        customerTrackComplaint("CUST1001");
        std::string o = c.getOutput();
        if (i == 1) EXPECT_NE(o.find("[Stage 1/5] Received & Queued for Agent"), std::string::npos);
        else if (i == 2) EXPECT_NE(o.find("[Stage 2/5] Assigned to Support Agent"), std::string::npos);
        else if (i == 3) EXPECT_NE(o.find("[Stage 3/5] Active Investigation & Troubleshooting"), std::string::npos);
        else if (i == 4) EXPECT_NE(o.find("[Stage 3.5/5] Escalated for Senior Technical Review"), std::string::npos);
        else if (i == 5) EXPECT_NE(o.find("[Stage 4/5] Resolution Provided"), std::string::npos);
        else if (i == 6) EXPECT_NE(o.find("[Stage 5/5] Formally Closed"), std::string::npos);
        else if (i == 7) EXPECT_NE(o.find("Current State: CUSTOM_STATUS"), std::string::npos);
    }
}

/* ========================================================================= */
/* FUNCTION 18: customerViewHistory Tests                                    */
/* ========================================================================= */

TEST_F(CustomerTest, CustomerViewHistory_ValidationAndAuditRecords) {
    // 1. Complaint not found
    {
        StdioCapture capture("CMP999\n");
        customerViewHistory("CUST1001");
        EXPECT_NE(capture.getOutput().find("Error: Complaint ID 'CMP999' not found"), std::string::npos);
    }
    // 2. Security violation
    {
        freeAllMemory();
        sandbox.writeFile("data/complaints.txt",
            "CMP101|CUST1002|Technical Support|High|ASSIGNED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|Desc\n");
        initSystem();

        StdioCapture capture("CMP101\n");
        customerViewHistory("CUST1001");
        EXPECT_NE(capture.getOutput().find("Security violation: You can only view audit history for your own complaints"), std::string::npos);
    }
    // 3. Zero audit records
    {
        freeAllMemory();
        sandbox.writeFile("data/complaints.txt",
            "CMP101|CUST1001|Technical Support|High|PENDING|UNASSIGNED|2026-01-01 10:00:00|N/A|2026-01-01 10:00:00|N/A|N/A|N/A|Note|Desc\n");
        sandbox.writeFile("data/audit_log.txt", ""); // clear audit log
        initSystem();

        StdioCapture capture("CMP101\n");
        customerViewHistory("CUST1001");
        EXPECT_NE(capture.getOutput().find("No audit records found for this complaint"), std::string::npos);
    }
    // 4. Multiple audit records displayed
    {
        freeAllMemory();
        sandbox.writeFile("data/complaints.txt",
            "CMP101|CUST1001|Technical Support|High|ASSIGNED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|Desc\n");
        sandbox.writeFile("data/audit_log.txt",
            "CMP101|2026-01-01 10:00:00|REGISTERED|CUST1001|Lodge ticket\n"
            "CMP101|2026-01-01 10:05:00|ASSIGNED|SYSTEM|Auto assigned to AGT101\n");
        initSystem();

        StdioCapture capture("CMP101\n");
        customerViewHistory("CUST1001");
        std::string out = capture.getOutput();
        EXPECT_NE(out.find("REGISTERED"), std::string::npos);
        EXPECT_NE(out.find("Lodge ticket"), std::string::npos);
        EXPECT_NE(out.find("ASSIGNED"), std::string::npos);
        EXPECT_NE(out.find("Auto assigned to AGT101"), std::string::npos);
    }
}
