#include "test_helpers.h"
#include "../include/escalation.h"

class EscalationTest : public ::testing::Test {
protected:
    ScopedSandbox sandbox;

    void SetUp() override {
        g_escalation_clock = 0;
        initSystem();
    }

    void TearDown() override {
        g_escalation_clock = 0;
        freeAllMemory();
    }
};

/* ========================================================================= */
/* FEATURE 2 & 3: 24-Hour Automatic Escalation & Manager Review Tests        */
/* ========================================================================= */

TEST_F(EscalationTest, LessThan24Hours_DoesNotEscalate) {
    freeAllMemory();
    // Complaint registered at 2026-01-01 10:00:00
    sandbox.writeFile("data/complaints.txt",
        "CMP101|CUST1001|Technical Support|High|ASSIGNED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|Fiber cut\n");
    initSystem();

    // Reference time: 23 hours later (2026-01-02 09:00:00, 82800s elapsed < 86400s)
    time_t refTime = parseComplaintTimestamp("2026-01-02 09:00:00");
    ASSERT_NE(refTime, (time_t)-1);

    int escalated = checkAndEscalateComplaints(refTime, NULL);
    EXPECT_EQ(escalated, 0);

    ComplaintNode *node = findComplaintById("CMP101");
    ASSERT_NE(node, nullptr);
    EXPECT_STREQ(node->data.status, "ASSIGNED");
    EXPECT_STREQ(node->data.timestamps.escalated, "N/A");
}

TEST_F(EscalationTest, Exactly24Hours_EscalatesAutomatically) {
    freeAllMemory();
    sandbox.writeFile("data/complaints.txt",
        "CMP101|CUST1001|Technical Support|High|ASSIGNED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|Fiber cut\n");
    initSystem();

    // Exactly 24 hours later (2026-01-02 10:00:00, 86400s elapsed)
    time_t refTime = parseComplaintTimestamp("2026-01-02 10:00:00");
    ASSERT_NE(refTime, (time_t)-1);

    int escalated = checkAndEscalateComplaints(refTime, NULL);
    EXPECT_EQ(escalated, 1);

    ComplaintNode *node = findComplaintById("CMP101");
    ASSERT_NE(node, nullptr);
    EXPECT_STREQ(node->data.status, "ESCALATED");
    EXPECT_STREQ(node->data.timestamps.escalated, "2026-01-02 10:00:00");
    EXPECT_STREQ(node->data.lastNote, "Automatically escalated after 24 hours without resolution.");

    // Verify audit entry appended
    ASSERT_NE(node->auditHead, nullptr);
    const AuditNode *lastAudit = node->auditHead;
    while (lastAudit->next != NULL) {
        lastAudit = lastAudit->next;
    }
    EXPECT_STREQ(lastAudit->action, "ESCALATED");
    EXPECT_STREQ(lastAudit->performedBy, "SYSTEM");
    EXPECT_STREQ(lastAudit->details, "Automatically escalated after 24 hours without resolution.");
}

TEST_F(EscalationTest, MoreThan24Hours_EscalatesWithPreservedRegistrationTimestamp) {
    freeAllMemory();
    sandbox.writeFile("data/complaints.txt",
        "CMP101|CUST1001|Billing and Account|Medium|IN_PROGRESS|AGT102|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Initial|Bill issue\n");
    initSystem();

    // 48 hours later (2026-01-03 10:00:00)
    time_t refTime = parseComplaintTimestamp("2026-01-03 10:00:00");
    ASSERT_NE(refTime, (time_t)-1);

    int escalated = checkAndEscalateComplaints(refTime, NULL);
    EXPECT_EQ(escalated, 1);

    ComplaintNode *node = findComplaintById("CMP101");
    ASSERT_NE(node, nullptr);
    EXPECT_STREQ(node->data.status, "ESCALATED");
    // Registration timestamp must be strictly preserved
    EXPECT_STREQ(node->data.timestamps.registered, "2026-01-01 10:00:00");
    EXPECT_STREQ(node->data.timestamps.escalated, "2026-01-03 10:00:00");
}

TEST_F(EscalationTest, ResolvedAndClosedComplaints_NeverEscalated) {
    freeAllMemory();
    sandbox.writeFile("data/complaints.txt",
        "CMP101|CUST1001|Tech|Low|RESOLVED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 11:00:00|2026-01-01 11:00:00|N/A|N/A|Resolved|Done\n"
        "CMP102|CUST1001|Billing|Low|CLOSED|AGT102|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 12:00:00|2026-01-01 11:00:00|2026-01-01 12:00:00|N/A|Closed|Done\n");
    initSystem();

    // Check 5 days later (2026-01-06 10:00:00)
    time_t refTime = parseComplaintTimestamp("2026-01-06 10:00:00");
    ASSERT_NE(refTime, (time_t)-1);

    int escalated = checkAndEscalateComplaints(refTime, NULL);
    EXPECT_EQ(escalated, 0);

    ComplaintNode *c1 = findComplaintById("CMP101");
    ASSERT_NE(c1, nullptr);
    EXPECT_STREQ(c1->data.status, "RESOLVED");

    ComplaintNode *c2 = findComplaintById("CMP102");
    ASSERT_NE(c2, nullptr);
    EXPECT_STREQ(c2->data.status, "CLOSED");
}

TEST_F(EscalationTest, RepeatedExecutionsAreIdempotent) {
    freeAllMemory();
    sandbox.writeFile("data/complaints.txt",
        "CMP101|CUST1001|Tech|High|ASSIGNED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|Test\n");
    initSystem();

    time_t refTime1 = parseComplaintTimestamp("2026-01-02 11:00:00");
    int firstRun = checkAndEscalateComplaints(refTime1, NULL);
    EXPECT_EQ(firstRun, 1);

    // Count audit entries after first run
    ComplaintNode *node = findComplaintById("CMP101");
    ASSERT_NE(node, nullptr);
    int auditCount = 0;
    const AuditNode *an = node->auditHead;
    while (an != NULL) {
        auditCount++;
        an = an->next;
    }

    // Second run 5 minutes later: must be idempotent (0 newly escalated, zero extra audits)
    time_t refTime2 = parseComplaintTimestamp("2026-01-02 11:05:00");
    int secondRun = checkAndEscalateComplaints(refTime2, NULL);
    EXPECT_EQ(secondRun, 0);

    int auditCount2 = 0;
    an = node->auditHead;
    while (an != NULL) {
        auditCount2++;
        an = an->next;
    }
    EXPECT_EQ(auditCount, auditCount2);
}

TEST_F(EscalationTest, MultipleOverdueComplaints_BatchEscalated) {
    freeAllMemory();
    sandbox.writeFile("data/complaints.txt",
        "CMP101|CUST1001|Tech|High|PENDING|UNASSIGNED|2026-01-01 10:00:00|N/A|2026-01-01 10:00:00|N/A|N/A|N/A|Note|T1\n"
        "CMP102|CUST1001|Billing|Medium|ASSIGNED|AGT101|2026-01-01 12:00:00|2026-01-01 12:00:00|2026-01-01 12:00:00|N/A|N/A|N/A|Note|T2\n"
        "CMP103|CUST1001|Logistics|Low|RESOLVED|AGT102|2026-01-01 08:00:00|2026-01-01 08:00:00|2026-01-01 09:00:00|2026-01-01 09:00:00|N/A|N/A|Note|T3\n"
        "CMP104|CUST1001|Service|Low|IN_PROGRESS|AGT103|2026-01-02 08:00:00|2026-01-02 08:00:00|2026-01-02 08:00:00|N/A|N/A|N/A|Note|T4\n");
    initSystem();

    // Reference time: 2026-01-02 13:00:00
    // CMP101: 27 hours -> Overdue -> ESCALATED
    // CMP102: 25 hours -> Overdue -> ESCALATED
    // CMP103: RESOLVED -> Ignored
    // CMP104: 5 hours  -> Not overdue -> Ignored
    time_t refTime = parseComplaintTimestamp("2026-01-02 13:00:00");
    int escalated = checkAndEscalateComplaints(refTime, NULL);
    EXPECT_EQ(escalated, 2);

    EXPECT_STREQ(findComplaintById("CMP101")->data.status, "ESCALATED");
    EXPECT_STREQ(findComplaintById("CMP102")->data.status, "ESCALATED");
    EXPECT_STREQ(findComplaintById("CMP103")->data.status, "RESOLVED");
    EXPECT_STREQ(findComplaintById("CMP104")->data.status, "IN_PROGRESS");
}

TEST_F(EscalationTest, RecoveryAcrossApplicationRestart) {
    freeAllMemory();
    sandbox.writeFile("data/complaints.txt",
        "CMP101|CUST1001|Tech|High|ASSIGNED|AGT101|2020-01-01 10:00:00|2020-01-01 10:00:00|2020-01-01 10:00:00|N/A|N/A|N/A|Note|Very Old\n");

    // Initialize system simulates application startup after downtime
    initSystem();

    ComplaintNode *node = findComplaintById("CMP101");
    ASSERT_NE(node, nullptr);
    // Since 2020 is > 24 hours ago, initSystem() must have auto-escalated it upon startup
    EXPECT_STREQ(node->data.status, "ESCALATED");
}

TEST_F(EscalationTest, ManagerViewEscalatedComplaints_Display) {
    freeAllMemory();
    // 1 Unresolved Escalated, 1 Resolved Escalated
    sandbox.writeFile("data/complaints.txt",
        "CMP101|CUST1001|Tech|High|ESCALATED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-02 10:00:00|N/A|N/A|2026-01-02 10:00:00|Auto escalated note|Fiber break\n"
        "CMP102|CUST1001|Billing|Low|RESOLVED|AGT102|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-03 10:00:00|2026-01-03 10:00:00|N/A|2026-01-02 10:00:00|Resolved later|Fee refund\n");
    sandbox.writeFile("data/audit_log.txt",
        "CMP101|2026-01-02 10:00:00|ESCALATED|SYSTEM|Automatically escalated after 24 hours without resolution.\n"
        "CMP102|2026-01-02 10:00:00|ESCALATED|SYSTEM|Automatically escalated after 24 hours without resolution.\n");
    initSystem();

    StdioCapture capture;
    managerViewEscalatedComplaints();

    std::string out = capture.getOutput();
    EXPECT_NE(out.find("ESCALATED COMPLAINTS REVIEW"), std::string::npos);
    EXPECT_NE(out.find("CMP101"), std::string::npos);
    EXPECT_NE(out.find("CMP102"), std::string::npos);
    EXPECT_NE(out.find("[UNRESOLVED]"), std::string::npos);
    EXPECT_NE(out.find("Fiber break"), std::string::npos);
    EXPECT_NE(out.find("Automatically escalated after 24 hours without resolution."), std::string::npos);
    EXPECT_NE(out.find("Total Escalated: 2"), std::string::npos);
}

TEST_F(EscalationTest, ManagerViewEscalatedComplaints_EmptyList) {
    freeAllMemory();
    initSystem();

    StdioCapture capture;
    managerViewEscalatedComplaints();

    std::string out = capture.getOutput();
    EXPECT_NE(out.find("No escalated complaints found in the system."), std::string::npos);
}

TEST_F(EscalationTest, ManagerDashboard_Option7_ViewEscalatedComplaints) {
    freeAllMemory();
    sandbox.writeFile("data/complaints.txt",
        "CMP101|CUST1001|Tech|High|ESCALATED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-02 10:00:00|N/A|N/A|2026-01-02 10:00:00|Note|Router issue\n");
    initSystem();

    // Manager dashboard: select 7 (View Escalated Complaints), then 6 (Logout)
    StdioCapture capture("7\n6\n");
    managerDashboard();

    std::string out = capture.getOutput();
    EXPECT_NE(out.find("ESCALATED COMPLAINTS REVIEW"), std::string::npos);
    EXPECT_NE(out.find("CMP101"), std::string::npos);
    EXPECT_NE(out.find("Router issue"), std::string::npos);
    EXPECT_NE(out.find("Logging out of manager session"), std::string::npos);
}

TEST_F(EscalationTest, ManagerMenu_Option3_ViewEscalatedComplaints) {
    freeAllMemory();
    sandbox.writeFile("data/complaints.txt",
        "CMP101|CUST1001|Tech|High|ESCALATED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-02 10:00:00|N/A|N/A|2026-01-02 10:00:00|Note|Server down\n");
    initSystem();

    // Manager Portal: select 3 (View Escalated Complaints), authenticate with manager/manager123, then 2 (Return)
    StdioCapture capture("3\nmanager\nmanager123\n2\n");
    managerMenu();

    std::string out = capture.getOutput();
    EXPECT_NE(out.find("Manager Authentication Required"), std::string::npos);
    EXPECT_NE(out.find("Authenticated as Operations Manager"), std::string::npos);
    EXPECT_NE(out.find("ESCALATED COMPLAINTS REVIEW"), std::string::npos);
    EXPECT_NE(out.find("Server down"), std::string::npos);
}
