#include "test_helpers.h"
#include "../include/security.h"

class PasswordHashingTest : public ::testing::Test {
protected:
    ScopedSandbox sandbox;

    void SetUp() override {
        initSystem();
    }

    void TearDown() override {
        freeAllMemory();
    }
};

/* ========================================================================= */
/* FEATURE 1: Password Hashing & Security Verification Tests                 */
/* ========================================================================= */

TEST_F(PasswordHashingTest, UniqueSaltsForIdenticalPasswords) {
    char hash1[128];
    char hash2[128];

    ASSERT_EQ(hashPassword("MySecretPassword123!", hash1, sizeof(hash1)), 1);
    ASSERT_EQ(hashPassword("MySecretPassword123!", hash2, sizeof(hash2)), 1);

    // Both must verify correctly against original password
    EXPECT_EQ(verifyPassword("MySecretPassword123!", hash1), 1);
    EXPECT_EQ(verifyPassword("MySecretPassword123!", hash2), 1);

    // Hashes must be distinct due to unique random per-password salt
    EXPECT_STRNE(hash1, hash2);
}

TEST_F(PasswordHashingTest, CorrectPasswordVerificationAndWrongPasswordRejection) {
    char hash[128];
    ASSERT_EQ(hashPassword("ComplexPass_2026", hash, sizeof(hash)), 1);

    // Correct password must authenticate
    EXPECT_EQ(verifyPassword("ComplexPass_2026", hash), 1);

    // Incorrect passwords must fail safely
    EXPECT_EQ(verifyPassword("wrongpass", hash), 0);
    EXPECT_EQ(verifyPassword("complexpass_2026", hash), 0); // Case-sensitive
    EXPECT_EQ(verifyPassword("", hash), 0);
    EXPECT_EQ(verifyPassword(NULL, hash), 0);
}

TEST_F(PasswordHashingTest, CustomerRegistrationStoresSecureHashNotPlaintext) {
    freeAllMemory();
    initSystem();

    // Register a new customer via customerRegister()
    StdioCapture capture("John Hash\njohnhash\nsuperSecret99\njohn@example.com\n");
    customerRegister();

    // Verify Customer record in memory
    CustomerNode *node = findCustomerByUsername("johnhash");
    ASSERT_NE(node, nullptr);

    // Plaintext password must NOT be stored
    EXPECT_STRNE(node->data.password, "superSecret99");

    // Must be hashed with standard MCF prefix ($pbkdf2-sha256$ or $argon2id$)
    EXPECT_EQ(isPasswordHashed(node->data.password), 1);

    // Verify stored file does NOT contain plaintext password
    std::string custFile = sandbox.readFile("data/customers.txt");
    EXPECT_EQ(custFile.find("superSecret99"), std::string::npos);
    EXPECT_NE(custFile.find("johnhash"), std::string::npos);

    // Verify customer can authenticate with the correct password
    EXPECT_EQ(verifyPassword("superSecret99", node->data.password), 1);
}

TEST_F(PasswordHashingTest, CustomerLegacyPlaintextMigrationOnLogin) {
    freeAllMemory();
    // Simulate legacy database with plaintext password
    sandbox.writeFile("data/customers.txt",
        "CUST1001|Legacy User|legacyuser|plainPassword123|legacy@test.com\n");
    initSystem();

    CustomerNode *node = findCustomerByUsername("legacyuser");
    ASSERT_NE(node, nullptr);
    EXPECT_STREQ(node->data.password, "plainPassword123");
    EXPECT_EQ(isPasswordHashed(node->data.password), 0);

    // Successful login by customer triggers migration
    StdioCapture capture("legacyuser\nplainPassword123\n5\n"); // Choice 5: logout
    customerLogin();

    // Stored password must now be migrated to secure hash
    EXPECT_EQ(isPasswordHashed(node->data.password), 1);
    EXPECT_STRNE(node->data.password, "plainPassword123");

    // Persistent file must now contain the hash, not plaintext
    std::string custFile = sandbox.readFile("data/customers.txt");
    EXPECT_EQ(custFile.find("plainPassword123"), std::string::npos);
    EXPECT_NE(custFile.find("legacyuser"), std::string::npos);

    // User can still authenticate on subsequent logins using new hash
    EXPECT_EQ(verifyPassword("plainPassword123", node->data.password), 1);
    EXPECT_EQ(verifyPassword("wrongPassword", node->data.password), 0);
}

TEST_F(PasswordHashingTest, AgentLegacyPlaintextMigrationOnLogin) {
    freeAllMemory();
    // Simulate legacy agents file with plaintext password
    sandbox.writeFile("data/agents.txt",
        "AGT101|Agent Alice|alice_agent|legacyAgentPass|1|3\n");
    initSystem();

    // Agent logs in with legacy password
    StdioCapture capture("1\nalice_agent\nlegacyAgentPass\n4\n2\n"); // 1: Login, 4: Logout dashboard, 2: Return
    agentMenu();

    // Verify file now contains migrated secure hash, not plaintext
    std::string agentFile = sandbox.readFile("data/agents.txt");
    EXPECT_EQ(agentFile.find("legacyAgentPass"), std::string::npos);
    EXPECT_NE(agentFile.find("alice_agent"), std::string::npos);
}

TEST_F(PasswordHashingTest, ManagerLoginAndMigration) {
    // Manager login with manager123
    StdioCapture capture("1\nmanager\nmanager123\n6\n2\n"); // 1: Login, 6: Logout, 2: Return
    managerMenu();

    std::string out = capture.getOutput();
    EXPECT_NE(out.find("Welcome, Operations Manager!"), std::string::npos);
    EXPECT_NE(out.find("MANAGER DASHBOARD"), std::string::npos);
}

TEST_F(PasswordHashingTest, InvalidAndCorruptedHashHandling) {
    // Corrupted iterations count
    EXPECT_EQ(verifyPassword("mypass", "$pbkdf2-sha256$i=invalid$abcdef$012345"), 0);

    // Negative or zero iterations
    EXPECT_EQ(verifyPassword("mypass", "$pbkdf2-sha256$i=0$abcdef$012345"), 0);
    EXPECT_EQ(verifyPassword("mypass", "$pbkdf2-sha256$i=-100$abcdef$012345"), 0);

    // Truncated / malformed format
    EXPECT_EQ(verifyPassword("mypass", "$pbkdf2-sha256$truncated"), 0);
    EXPECT_EQ(verifyPassword("mypass", "$pbkdf2-sha256$"), 0);
    EXPECT_EQ(verifyPassword("mypass", "$"), 0);

    // Non-hex characters in salt or hash
    EXPECT_EQ(verifyPassword("mypass", "$pbkdf2-sha256$i=1000$not_hex_salt!$not_hex_hash!"), 0);

    // Safe handling: zero crash, returns 0 cleanly
}

TEST_F(PasswordHashingTest, NullAndEmptyGuards) {
    EXPECT_EQ(hashPassword(NULL, NULL, 0), 0);
    char buf[16]; // Too small buffer
    EXPECT_EQ(hashPassword("password", buf, sizeof(buf)), 0);

    EXPECT_EQ(verifyPassword(NULL, NULL), 0);
    EXPECT_EQ(verifyPassword("", "anyhash"), 0);
    EXPECT_EQ(verifyPassword("anypass", ""), 0);
    EXPECT_EQ(isPasswordHashed(NULL), 0);
    EXPECT_EQ(isPasswordHashed(""), 0);
}
