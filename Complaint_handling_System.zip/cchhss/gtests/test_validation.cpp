#include "test_helpers.h"

class ValidationTest : public ::testing::Test {
protected:
    void SetUp() override {}
    void TearDown() override {}
};

/* ========================================================================= */
/* FUNCTION 1: getTimestamp Tests                                            */
/* ========================================================================= */

TEST_F(ValidationTest, GetTimestamp_ValidFormatting) {
    char buffer[64];
    memset(buffer, 0, sizeof(buffer));
    getTimestamp(buffer, sizeof(buffer));

    EXPECT_EQ(strlen(buffer), 19u);
    EXPECT_EQ(buffer[4], '-');
    EXPECT_EQ(buffer[7], '-');
    EXPECT_EQ(buffer[10], ' ');
    EXPECT_EQ(buffer[13], ':');
    EXPECT_EQ(buffer[16], ':');
}

TEST_F(ValidationTest, GetTimestamp_NullBuffer_DoesNotCrash) {
    getTimestamp(NULL, 64);
}

TEST_F(ValidationTest, GetTimestamp_ZeroOrSmallSize_HandlesSafely) {
    // Zero size: buffer remains unmodified
    char zeroBuf[16] = "Unmodified";
    getTimestamp(zeroBuf, 0);
    EXPECT_STREQ(zeroBuf, "Unmodified");

    // Small size: strftime returns 0 safely without buffer overrun
    char smallBuf[5];
    memset(smallBuf, 0, sizeof(smallBuf));
    getTimestamp(smallBuf, sizeof(smallBuf));
    EXPECT_EQ(smallBuf[4], '\0');
}

TEST_F(ValidationTest, GetTimestamp_LocaltimeFailure_SetsNA) {
    char buffer[32];
    memset(buffer, 0, sizeof(buffer));
    {
        FailLocaltimeGuard guard;
        getTimestamp(buffer, sizeof(buffer));
    }
    EXPECT_STREQ(buffer, "N/A");
}

/* ========================================================================= */
/* FUNCTION 2: readString Tests                                              */
/* ========================================================================= */

TEST_F(ValidationTest, ReadString_NormalInput_StripsNewline) {
    StdioCapture capture("Hello World\n");
    char buffer[64];
    readString("Enter text: ", buffer, sizeof(buffer));

    EXPECT_STREQ(buffer, "Hello World");
    EXPECT_NE(capture.getOutput().find("Enter text: "), std::string::npos);
}

TEST_F(ValidationTest, ReadString_WindowsCRLF_StripsBothCharacters) {
    StdioCapture capture("Windows Line\r\n");
    char buffer[64];
    readString(NULL, buffer, sizeof(buffer));

    EXPECT_STREQ(buffer, "Windows Line");
}

TEST_F(ValidationTest, ReadString_PipeCharacterReplacement) {
    StdioCapture capture("user|data|injection|attempt\n");
    char buffer[64];
    readString("", buffer, sizeof(buffer));

    EXPECT_STREQ(buffer, "user-data-injection-attempt");
}

TEST_F(ValidationTest, ReadString_PromptsAndBufferBoundaries) {
    // Null prompt
    {
        StdioCapture capture("NoPrompt\n");
        char buf[32];
        readString(NULL, buf, sizeof(buf));
        EXPECT_STREQ(buf, "NoPrompt");
        EXPECT_TRUE(capture.getOutput().empty());
    }
    // Null buffer or zero size
    {
        StdioCapture capture("Test\n");
        readString("Prompt: ", NULL, 32);
        char buf[10] = "Keep";
        readString("Prompt: ", buf, 0);
        EXPECT_STREQ(buf, "Keep");
    }
}

TEST_F(ValidationTest, ReadString_EOFAndEmptyLine) {
    // Immediate EOF
    {
        StdioCapture capture("");
        char buffer[64] = "NotEmpty";
        readString("Prompt: ", buffer, sizeof(buffer));
        EXPECT_STREQ(buffer, "");
    }
    // Empty input line (\n only)
    {
        StdioCapture capture("\n");
        char buffer[64] = "NotEmpty";
        readString("Prompt: ", buffer, sizeof(buffer));
        EXPECT_STREQ(buffer, "");
    }
}

/* ========================================================================= */
/* FUNCTION 3: readInt Tests                                                 */
/* ========================================================================= */

TEST_F(ValidationTest, ReadInt_ValidAndBoundaries) {
    // Value within range
    {
        StdioCapture capture("3\n");
        EXPECT_EQ(readInt("Select: ", 1, 5), 3);
    }
    // Exact lower boundary
    {
        StdioCapture capture("1\n");
        EXPECT_EQ(readInt("Select: ", 1, 10), 1);
    }
    // Exact upper boundary
    {
        StdioCapture capture("10\n");
        EXPECT_EQ(readInt("Select: ", 1, 10), 10);
    }
}

TEST_F(ValidationTest, ReadInt_InvalidInputsReprompt) {
    // Exercises: below range (0), above range (6), non-numeric (invalid), trailing chars (12abc), empty input (\n)
    StdioCapture capture("0\n6\ninvalid\n12abc\n\n4\n");
    int val = readInt("Select (1-5): ", 1, 5);
    EXPECT_EQ(val, 4);

    std::string out = capture.getOutput();
    EXPECT_NE(out.find("Invalid choice"), std::string::npos);
    EXPECT_NE(out.find("Input cannot be empty"), std::string::npos);
}

TEST_F(ValidationTest, ReadInt_ImmediateEOF_ReturnsMinVal) {
    StdioCapture capture("");
    EXPECT_EQ(readInt("Select: ", 2, 8), 2);
}
