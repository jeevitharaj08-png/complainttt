#ifndef ESCALATION_H
#define ESCALATION_H

#include "complaint_system.h"
#include <time.h>
#include <fcntl.h>
#include <sys/stat.h>

#ifdef _WIN32
#include <io.h>
#include <windows.h>
#else
#include <unistd.h>
#include <sys/file.h>
#endif

#define ESCALATION_THRESHOLD_SECONDS 86400 /* 24 hours */
#define ESCALATION_DEFAULT_REASON "Automatically escalated after 24 hours without resolution."

#ifdef __cplusplus
extern "C" {
#endif

/* Global injectable clock seam for testing */
extern time_t g_escalation_clock;

/* Parse "YYYY-MM-DD HH:MM:SS" into time_t */
static inline time_t parseComplaintTimestamp(const char *str) {
    if (str == NULL || strlen(str) < 19) {
        return (time_t)-1;
    }
    struct tm tm_val;
    memset(&tm_val, 0, sizeof(tm_val));
    int year, month, day, hour, min, sec;
    if (sscanf(str, "%d-%d-%d %d:%d:%d", &year, &month, &day, &hour, &min, &sec) == 6) {
        tm_val.tm_year = year - 1900;
        tm_val.tm_mon  = month - 1;
        tm_val.tm_mday = day;
        tm_val.tm_hour = hour;
        tm_val.tm_min  = min;
        tm_val.tm_sec  = sec;
        tm_val.tm_isdst = -1;
        return mktime(&tm_val);
    }
    return (time_t)-1;
}

/* Format time_t into "YYYY-MM-DD HH:MM:SS" */
static inline void formatComplaintTimestamp(time_t t, char *buffer, size_t size) {
    if (buffer == NULL || size == 0) {
        return;
    }
    const struct tm *tm_info = localtime(&t);
    if (tm_info != NULL) {
        (void)strftime(buffer, size, "%Y-%m-%d %H:%M:%S", tm_info);
    } else {
        (void)snprintf(buffer, size, "N/A");
    }
}

/* Portable file locking for concurrency protection between cron and application */
static inline int acquireDataLock(void) {
#ifndef _WIN32
    int fd = open("data/.lock", O_CREAT | O_RDWR, 0666);
    if (fd < 0) return -1;
    struct flock fl;
    memset(&fl, 0, sizeof(fl));
    fl.l_type = F_WRLCK;
    fl.l_whence = SEEK_SET;
    fl.l_start = 0;
    fl.l_len = 0;
    if (fcntl(fd, F_SETLK, &fl) < 0) {
        close(fd);
        return -1;
    }
    return fd;
#else
    return 0;
#endif
}

static inline void releaseDataLock(int fd) {
#ifndef _WIN32
    if (fd >= 0) {
        struct flock fl;
        memset(&fl, 0, sizeof(fl));
        fl.l_type = F_UNLCK;
        fl.l_whence = SEEK_SET;
        fl.l_start = 0;
        fl.l_len = 0;
        (void)fcntl(fd, F_SETLK, &fl);
        close(fd);
    }
#else
    (void)fd;
#endif
}

#ifdef CHS_ESCALATION_IMPL
int checkAndEscalateComplaints(time_t referenceTime, const char *reason) {
    time_t now = referenceTime;
    if (now == 0) {
        if (g_escalation_clock != 0) {
            now = g_escalation_clock;
        } else {
            now = time(NULL);
        }
    }
    const char *escReason = (reason != NULL && reason[0] != '\0') ? reason : ESCALATION_DEFAULT_REASON;
    char nowStr[26];
    formatComplaintTimestamp(now, nowStr, sizeof(nowStr));

    int escalatedCount = 0;
    ComplaintNode *curr = complaintHead;
    while (curr != NULL) {
        if ((strcmp(curr->data.status, "RESOLVED") != 0) &&
            (strcmp(curr->data.status, "CLOSED") != 0) &&
            (strcmp(curr->data.status, "ESCALATED") != 0)) {
            time_t regTime = parseComplaintTimestamp(curr->data.timestamps.registered);
            if (regTime != (time_t)-1) {
                double elapsed = difftime(now, regTime);
                if (elapsed >= (double)ESCALATION_THRESHOLD_SECONDS) {
                    (void)snprintf(curr->data.status, sizeof(curr->data.status), "ESCALATED");
                    (void)snprintf(curr->data.timestamps.escalated, sizeof(curr->data.timestamps.escalated), "%s", nowStr);
                    (void)snprintf(curr->data.timestamps.updated, sizeof(curr->data.timestamps.updated), "%s", nowStr);
                    (void)snprintf(curr->data.lastNote, sizeof(curr->data.lastNote), "%s", escReason);
                    addAuditEntry(curr, "ESCALATED", "SYSTEM", escReason);
                    escalatedCount++;
                }
            }
        }
        curr = curr->next;
    }

    if (escalatedCount > 0) {
        saveAllData();
    }
    return escalatedCount;
}
#else
int checkAndEscalateComplaints(time_t referenceTime, const char *reason);
#endif

#ifdef __cplusplus
}
#endif

#endif /* ESCALATION_H */
