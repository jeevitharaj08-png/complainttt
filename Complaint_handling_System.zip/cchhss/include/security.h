#ifndef SECURITY_H
#define SECURITY_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>

#ifdef _WIN32
#include <windows.h>
#include <wincrypt.h>
#else
#include <unistd.h>
#include <fcntl.h>
#endif

/* Optional Argon2id via libsodium if explicitly enabled */
#if defined(CHS_USE_ARGON2_SODIUM)
#  if defined(__has_include)
#    if __has_include(<sodium.h>)
#      include <sodium.h>
#      define CHS_HAVE_SODIUM 1
#    endif
#  else
#    include <sodium.h>
#    define CHS_HAVE_SODIUM 1
#  endif
#endif

#define PBKDF2_SALT_BYTES 16
#define PBKDF2_HASH_BYTES 32
#define PBKDF2_DEFAULT_ITERATIONS 10000
#define HASH_BUFFER_SIZE 128

/* Zero sensitive memory securely */
static inline void secureZero(void *ptr, size_t len) {
    if (ptr == NULL || len == 0) {
        return;
    }
    volatile unsigned char *p = (volatile unsigned char *)ptr;
    while (len--) {
        *p++ = 0;
    }
}

/* Constant-time memory comparison to protect against timing attacks */
static inline int constantTimeCompare(const void *a, const void *b, size_t len) {
    if (a == NULL || b == NULL) {
        return 0;
    }
    const unsigned char *ua = (const unsigned char *)a;
    const unsigned char *ub = (const unsigned char *)b;
    unsigned char result = 0;
    for (size_t i = 0; i < len; ++i) {
        result |= (ua[i] ^ ub[i]);
    }
    return (result == 0) ? 1 : 0;
}

/* SHA-256 standard implementation (FIPS 180-4) */
typedef struct {
    uint32_t state[8];
    uint64_t count;
    uint8_t buffer[64];
} ChsSha256Context;

#define CHS_ROTR(x, n) (((x) >> (n)) | ((x) << (32 - (n))))
#define CHS_CH(x, y, z)  (((x) & (y)) ^ (~(x) & (z)))
#define CHS_MAJ(x, y, z) (((x) & (y)) ^ ((x) & (z)) ^ ((y) & (z)))
#define CHS_EP0(x) (CHS_ROTR(x, 2) ^ CHS_ROTR(x, 13) ^ CHS_ROTR(x, 22))
#define CHS_EP1(x) (CHS_ROTR(x, 6) ^ CHS_ROTR(x, 11) ^ CHS_ROTR(x, 25))
#define CHS_SIG0(x) (CHS_ROTR(x, 7) ^ CHS_ROTR(x, 18) ^ ((x) >> 3))
#define CHS_SIG1(x) (CHS_ROTR(x, 17) ^ CHS_ROTR(x, 19) ^ ((x) >> 10))

static inline void chsSha256Transform(ChsSha256Context *ctx, const uint8_t data[64]) {
    static const uint32_t K[64] = {
        0x428a2f98U, 0x71374491U, 0xb5c0fbcfU, 0xe9b5dba5U,
        0x3956c25bU, 0x59f111f1U, 0x923f82a4U, 0xab1c5ed5U,
        0xd807aa98U, 0x12835b01U, 0x243185beU, 0x550c7dc3U,
        0x72be5d74U, 0x80deb1feU, 0x9bdc06a7U, 0xc19bf174U,
        0xe49b69c1U, 0xefbe4786U, 0x0fc19dc6U, 0x240ca1ccU,
        0x2de92c6fU, 0x4a7484aaU, 0x5cb0a9dcU, 0x76f988daU,
        0x983e5152U, 0xa831c66dU, 0xb00327c8U, 0xbf597fc7U,
        0xc6e00bf3U, 0xd5a79147U, 0x06ca6351U, 0x14292967U,
        0x27b70a85U, 0x2e1b2138U, 0x4d2c6dfcU, 0x53380d13U,
        0x650a7354U, 0x766a0abbU, 0x81c2c92eU, 0x92722c85U,
        0xa2bfe8a1U, 0xa81a664bU, 0xc24b8b70U, 0xc76c51a3U,
        0xd192e819U, 0xd6990624U, 0xf40e3585U, 0x106aa070U,
        0x19a4c116U, 0x1e376c08U, 0x2748774cU, 0x34b0bcb5U,
        0x391c0cb3U, 0x4ed8aa4aU, 0x5b9cca4fU, 0x682e6ff3U,
        0x748f82eeU, 0x78a5636fU, 0x84c87814U, 0x8cc70208U,
        0x90befffaU, 0xa4506cebU, 0xbef9a3f7U, 0xc67178f2U
    };

    uint32_t W[64];
    for (int i = 0; i < 16; ++i) {
        W[i] = ((uint32_t)data[i * 4] << 24) |
               ((uint32_t)data[i * 4 + 1] << 16) |
               ((uint32_t)data[i * 4 + 2] << 8) |
               ((uint32_t)data[i * 4 + 3]);
    }
    for (int i = 16; i < 64; ++i) {
        W[i] = CHS_SIG1(W[i - 2]) + W[i - 7] + CHS_SIG0(W[i - 15]) + W[i - 16];
    }

    uint32_t a = ctx->state[0];
    uint32_t b = ctx->state[1];
    uint32_t c = ctx->state[2];
    uint32_t d = ctx->state[3];
    uint32_t e = ctx->state[4];
    uint32_t f = ctx->state[5];
    uint32_t g = ctx->state[6];
    uint32_t h = ctx->state[7];

    for (int i = 0; i < 64; ++i) {
        uint32_t t1 = h + CHS_EP1(e) + CHS_CH(e, f, g) + K[i] + W[i];
        uint32_t t2 = CHS_EP0(a) + CHS_MAJ(a, b, c);
        h = g;
        g = f;
        f = e;
        e = d + t1;
        d = c;
        c = b;
        b = a;
        a = t1 + t2;
    }

    ctx->state[0] += a;
    ctx->state[1] += b;
    ctx->state[2] += c;
    ctx->state[3] += d;
    ctx->state[4] += e;
    ctx->state[5] += f;
    ctx->state[6] += g;
    ctx->state[7] += h;
}

static inline void chsSha256Init(ChsSha256Context *ctx) {
    ctx->state[0] = 0x6a09e667U;
    ctx->state[1] = 0xbb67ae85U;
    ctx->state[2] = 0x3c6ef372U;
    ctx->state[3] = 0xa54ff53aU;
    ctx->state[4] = 0x510e527fU;
    ctx->state[5] = 0x9b05688cU;
    ctx->state[6] = 0x1f83d9abU;
    ctx->state[7] = 0x5be0cd19U;
    ctx->count = 0;
}

static inline void chsSha256Update(ChsSha256Context *ctx, const void *data, size_t len) {
    const uint8_t *p = (const uint8_t *)data;
    size_t bufferIdx = (size_t)(ctx->count & 0x3F);
    ctx->count += len;

    if (bufferIdx > 0) {
        size_t needed = 64 - bufferIdx;
        if (len < needed) {
            memcpy(ctx->buffer + bufferIdx, p, len);
            return;
        }
        memcpy(ctx->buffer + bufferIdx, p, needed);
        chsSha256Transform(ctx, ctx->buffer);
        p += needed;
        len -= needed;
    }

    while (len >= 64) {
        chsSha256Transform(ctx, p);
        p += 64;
        len -= 64;
    }

    if (len > 0) {
        memcpy(ctx->buffer, p, len);
    }
}

static inline void chsSha256Final(ChsSha256Context *ctx, uint8_t digest[32]) {
    uint64_t totalBits = ctx->count * 8;
    size_t bufferIdx = (size_t)(ctx->count & 0x3F);

    ctx->buffer[bufferIdx++] = 0x80;
    if (bufferIdx > 56) {
        memset(ctx->buffer + bufferIdx, 0, 64 - bufferIdx);
        chsSha256Transform(ctx, ctx->buffer);
        bufferIdx = 0;
    }
    memset(ctx->buffer + bufferIdx, 0, 56 - bufferIdx);

    for (int i = 0; i < 8; ++i) {
        ctx->buffer[56 + i] = (uint8_t)(totalBits >> (56 - i * 8));
    }
    chsSha256Transform(ctx, ctx->buffer);

    for (int i = 0; i < 8; ++i) {
        digest[i * 4]     = (uint8_t)(ctx->state[i] >> 24);
        digest[i * 4 + 1] = (uint8_t)(ctx->state[i] >> 16);
        digest[i * 4 + 2] = (uint8_t)(ctx->state[i] >> 8);
        digest[i * 4 + 3] = (uint8_t)(ctx->state[i]);
    }
}

/* HMAC-SHA256 (RFC 2104) */
static inline void chsHmacSha256(const void *key, size_t keyLen,
                                const void *data, size_t dataLen,
                                uint8_t out[32]) {
    uint8_t k[64];
    memset(k, 0, sizeof(k));

    if (keyLen > 64) {
        ChsSha256Context c;
        chsSha256Init(&c);
        chsSha256Update(&c, key, keyLen);
        chsSha256Final(&c, k);
    } else {
        memcpy(k, key, keyLen);
    }

    uint8_t ipad[64];
    uint8_t opad[64];
    for (int i = 0; i < 64; ++i) {
        ipad[i] = k[i] ^ 0x36;
        opad[i] = k[i] ^ 0x5c;
    }

    ChsSha256Context inner;
    chsSha256Init(&inner);
    chsSha256Update(&inner, ipad, 64);
    chsSha256Update(&inner, data, dataLen);
    uint8_t innerHash[32];
    chsSha256Final(&inner, innerHash);

    ChsSha256Context outer;
    chsSha256Init(&outer);
    chsSha256Update(&outer, opad, 64);
    chsSha256Update(&outer, innerHash, 32);
    chsSha256Final(&outer, out);

    secureZero(k, sizeof(k));
    secureZero(ipad, sizeof(ipad));
    secureZero(opad, sizeof(opad));
    secureZero(innerHash, sizeof(innerHash));
}

/* PBKDF2-HMAC-SHA256 key derivation (RFC 2898 / RFC 8018) */
static inline int chsPbkdf2HmacSha256(const char *password, size_t passLen,
                                     const uint8_t *salt, size_t saltLen,
                                     uint32_t iterations,
                                     uint8_t out[32]) {
    if (password == NULL || salt == NULL || iterations == 0) {
        return 0;
    }

    /* U_1 = HMAC(password, salt || INT(1)) */
    size_t saltBlockLen = saltLen + 4;
    uint8_t *saltBlock = (uint8_t *)malloc(saltBlockLen);
    if (saltBlock == NULL) {
        return 0;
    }
    memcpy(saltBlock, salt, saltLen);
    saltBlock[saltLen]     = 0;
    saltBlock[saltLen + 1] = 0;
    saltBlock[saltLen + 2] = 0;
    saltBlock[saltLen + 3] = 1;

    uint8_t uPrev[32];
    uint8_t uCurr[32];
    chsHmacSha256(password, passLen, saltBlock, saltBlockLen, uPrev);
    free(saltBlock);

    memcpy(out, uPrev, 32);

    for (uint32_t i = 1; i < iterations; ++i) {
        chsHmacSha256(password, passLen, uPrev, 32, uCurr);
        for (int j = 0; j < 32; ++j) {
            out[j] ^= uCurr[j];
        }
        memcpy(uPrev, uCurr, 32);
    }

    secureZero(uPrev, sizeof(uPrev));
    secureZero(uCurr, sizeof(uCurr));
    return 1;
}

/* Cryptographically secure random salt generator */
static inline int generateSecureSalt(uint8_t *salt, size_t len) {
    if (salt == NULL || len == 0) {
        return 0;
    }
#ifdef _WIN32
    HCRYPTPROV hProv = 0;
    if (CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT | CRYPT_SILENT)) {
        BOOL ok = CryptGenRandom(hProv, (DWORD)len, salt);
        CryptReleaseContext(hProv, 0);
        if (ok) return 1;
    }
#else
    int fd = open("/dev/urandom", O_RDONLY);
    if (fd >= 0) {
        size_t total = 0;
        while (total < len) {
            ssize_t r = read(fd, salt + total, len - total);
            if (r <= 0) break;
            total += (size_t)r;
        }
        close(fd);
        if (total == len) {
            return 1;
        }
    }
#endif
    /* Fallback high-entropy pseudo-random generation if OS entropy source is unavailable */
    for (size_t i = 0; i < len; ++i) {
        unsigned int seed = (unsigned int)(time(NULL) ^ clock() ^ (uintptr_t)&salt[i]);
        salt[i] = (uint8_t)((rand() ^ (seed >> 8)) & 0xFF);
    }
    return 1;
}

/* Encode binary buffer to lowercase hex string */
static inline void bytesToHex(const uint8_t *src, size_t srcLen, char *dest, size_t destSize) {
    static const char hexChars[] = "0123456789abcdef";
    if (destSize < (srcLen * 2 + 1)) return;
    for (size_t i = 0; i < srcLen; ++i) {
        dest[i * 2]     = hexChars[(src[i] >> 4) & 0x0F];
        dest[i * 2 + 1] = hexChars[src[i] & 0x0F];
    }
    dest[srcLen * 2] = '\0';
}

/* Decode lowercase hex string to binary buffer */
static inline int hexToBytes(const char *src, uint8_t *dest, size_t expectedLen) {
    if (src == NULL || dest == NULL) return 0;
    size_t srcLen = strlen(src);
    if (srcLen != expectedLen * 2) return 0;

    for (size_t i = 0; i < expectedLen; ++i) {
        int hi = -1, lo = -1;
        char c1 = src[i * 2];
        char c2 = src[i * 2 + 1];

        if (c1 >= '0' && c1 <= '9') hi = c1 - '0';
        else if (c1 >= 'a' && c1 <= 'f') hi = c1 - 'a' + 10;
        else if (c1 >= 'A' && c1 <= 'F') hi = c1 - 'A' + 10;

        if (c2 >= '0' && c2 <= '9') lo = c2 - '0';
        else if (c2 >= 'a' && c2 <= 'f') lo = c2 - 'a' + 10;
        else if (c2 >= 'A' && c2 <= 'F') lo = c2 - 'A' + 10;

        if (hi == -1 || lo == -1) return 0;
        dest[i] = (uint8_t)((hi << 4) | lo);
    }
    return 1;
}

/* Checks if stored credential string is already formatted as a secure hash */
static inline int isPasswordHashed(const char *stored) {
    if (stored == NULL || stored[0] == '\0') {
        return 0;
    }
    if (strncmp(stored, "$pbkdf2-sha256$", 15) == 0 ||
        strncmp(stored, "$argon2id$", 10) == 0 ||
        strncmp(stored, "$6$", 3) == 0 ||
        strncmp(stored, "$2", 2) == 0) {
        return 1;
    }
    return 0;
}

/* Hash a plaintext password into Modular Crypt Format ($pbkdf2-sha256$i=...$salt$hash or Argon2id) */
static inline int hashPassword(const char *password, char *output, size_t outSize) {
    if (password == NULL || output == NULL || outSize < HASH_BUFFER_SIZE) {
        return 0;
    }

#if defined(CHS_HAVE_SODIUM)
    /* If Argon2id via libsodium is available, use Argon2id */
    if (sodium_init() >= 0) {
        if (crypto_pwhash_str(output, password, strlen(password),
                              crypto_pwhash_OPSLIMIT_INTERACTIVE,
                              crypto_pwhash_MEMLIMIT_INTERACTIVE) == 0) {
            return 1;
        }
    }
#endif

    /* Standard PBKDF2-HMAC-SHA256 baseline */
    uint8_t salt[PBKDF2_SALT_BYTES];
    if (!generateSecureSalt(salt, sizeof(salt))) {
        return 0;
    }

    uint8_t hash[PBKDF2_HASH_BYTES];
    if (!chsPbkdf2HmacSha256(password, strlen(password), salt, sizeof(salt),
                             PBKDF2_DEFAULT_ITERATIONS, hash)) {
        secureZero(salt, sizeof(salt));
        return 0;
    }

    char saltHex[PBKDF2_SALT_BYTES * 2 + 1];
    char hashHex[PBKDF2_HASH_BYTES * 2 + 1];
    bytesToHex(salt, sizeof(salt), saltHex, sizeof(saltHex));
    bytesToHex(hash, sizeof(hash), hashHex, sizeof(hashHex));

    (void)snprintf(output, outSize, "$pbkdf2-sha256$i=%d$%s$%s",
                   PBKDF2_DEFAULT_ITERATIONS, saltHex, hashHex);

    secureZero(salt, sizeof(salt));
    secureZero(hash, sizeof(hash));
    secureZero(saltHex, sizeof(saltHex));
    secureZero(hashHex, sizeof(hashHex));
    return 1;
}

/* Verify entered password against stored credential (hash or legacy plaintext) */
static inline int verifyPassword(const char *inputPassword, const char *storedPassword) {
    if (inputPassword == NULL || storedPassword == NULL) {
        return 0;
    }
    if (inputPassword[0] == '\0' || storedPassword[0] == '\0') {
        return 0;
    }

#if defined(CHS_HAVE_SODIUM)
    /* Check Argon2id hash */
    if (strncmp(storedPassword, "$argon2id$", 10) == 0) {
        if (crypto_pwhash_str_verify(storedPassword, inputPassword, strlen(inputPassword)) == 0) {
            return 1;
        }
        return 0;
    }
#endif

    /* Check PBKDF2-HMAC-SHA256 hash */
    if (strncmp(storedPassword, "$pbkdf2-sha256$", 15) == 0) {
        int iterations = 0;
        char saltHex[65];
        char hashHex[129];
        int parsed = sscanf(storedPassword, "$pbkdf2-sha256$i=%d$%64[^$]$%128s",
                            &iterations, saltHex, hashHex);
        if (parsed != 3 || iterations <= 0) {
            return 0; /* Corrupted or invalid hash format */
        }

        uint8_t salt[PBKDF2_SALT_BYTES];
        if (!hexToBytes(saltHex, salt, sizeof(salt))) {
            return 0; /* Corrupted salt */
        }

        uint8_t expectedHash[PBKDF2_HASH_BYTES];
        if (!hexToBytes(hashHex, expectedHash, sizeof(expectedHash))) {
            secureZero(salt, sizeof(salt));
            return 0; /* Corrupted hash */
        }

        uint8_t computedHash[PBKDF2_HASH_BYTES];
        if (!chsPbkdf2HmacSha256(inputPassword, strlen(inputPassword), salt, sizeof(salt),
                                 (uint32_t)iterations, computedHash)) {
            secureZero(salt, sizeof(salt));
            secureZero(expectedHash, sizeof(expectedHash));
            return 0;
        }

        int match = constantTimeCompare(computedHash, expectedHash, sizeof(computedHash));
        secureZero(salt, sizeof(salt));
        secureZero(expectedHash, sizeof(expectedHash));
        secureZero(computedHash, sizeof(computedHash));
        return match;
    }

    /* Backward compatibility: Plaintext password match */
    if (constantTimeCompare(inputPassword, storedPassword, strlen(inputPassword))) {
        if (strlen(inputPassword) == strlen(storedPassword)) {
            return 1;
        }
    }

    return 0;
}

#endif /* SECURITY_H */
