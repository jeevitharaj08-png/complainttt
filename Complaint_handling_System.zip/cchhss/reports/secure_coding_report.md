# Secure Coding and Memory Management Audit Report

**Project:** Complaint Handling System (`cchhss`)  
**Standard Targeted:** CERT C Secure Coding Standard & CWE Top 25  
**Assessment Date:** October 28, 2026  
**Auditor:** Senior Embedded & Security Engineer  

---

## 1. Executive Summary

This report documents the security audit, vulnerability assessment, and memory-safety hardening applied to the Complaint Handling System. The system processes user credentials, complaints, and administrative audit trails stored in persistent pipe-delimited text files.

All identified risks—including unbounded input parsing, format string vulnerabilities, delimiter injection, integer parsing overflows, and unvalidated memory allocations—have been audited, resolved, and verified.

---

## 2. Threat Vector Analysis & Hardening Measures

### A. Buffer Overflows & Bounded String Operations (CWE-120, CWE-121)
- **Vulnerability Risk:** Traditional C input functions such as `gets()` or unconstrained `scanf("%s")` can write beyond allocated buffer bounds, causing stack smashing and arbitrary code execution.
- **Implemented Protection:**
  - `fgets(buffer, (int)size, stdin)` is enforced universally across all console input via `readString()`.
  - In `initSystem()`, all file parser `sscanf()` format strings explicitly mandate field-width limits:
    - `char customerId[16]` &rarr; `%15[^|]`
    - `char fullName[64]` &rarr; `%63[^|]`
    - `char username[32]` &rarr; `%31[^|]`
    - `char password[32]` &rarr; `%31[^|]`
    - `char details[128]` &rarr; `%127[^\r\n]`
    - `char description[256]` &rarr; `%255[^\r\n]`
  - Output string formatting utilizes `snprintf()` with explicit `sizeof(dest)` destinations, guaranteeing null termination even upon string truncation.

### B. Delimiter Injection / Data Tampering (CWE-74)
- **Vulnerability Risk:** The persistent database uses the pipe character (`|`) as a column delimiter in `data/*.txt`. An adversarial user entering `"Bad|Data|Injected"` could alter field alignment, corrupting records or escalating privileges.
- **Implemented Protection:**
  - `readString()` inspects every read character and automatically sanitizes pipe delimiters:
    ```c
    for (size_t i = 0U; i < len; ++i) {
        if (buffer[i] == '|') {
            buffer[i] = '-';
        }
    }
    ```
  - This neutralizes injection attacks before input reaches any database or memory structure.

### C. Integer Overflow and Range Validation (CWE-190, CWE-20)
- **Vulnerability Risk:** Using `atoi()` does not detect integer overflows (`ERANGE`) and returns `0` upon failure, making invalid string inputs indistinguishable from valid zero values.
- **Implemented Protection:**
  - `readInt()` utilizes `strtol()` preceded by `errno = 0;`.
  - It validates that conversion occurred (`endptr != buffer`), that no trailing non-numeric characters exist (`*endptr == '\0'`), that no overflow occurred (`errno == 0`), and that the integer strictly resides in `[minVal, maxVal]`.

### D. Dynamic Memory Lifecycle & Leak Prevention (CWE-401, CWE-416)
- **Vulnerability Risk:** Allocation failures without checks cause immediate NULL pointer dereferences (`SIGSEGV`). Premature deallocation leads to use-after-free, while unreleased memory leaks memory across application lifetimes.
- **Implemented Protection:**
  - Every `malloc()` invocation (for `CustomerNode`, `ComplaintNode`, and `AuditNode`) is followed by an immediate NULL guard:
    ```c
    AuditNode *newAudit = (AuditNode *)malloc(sizeof(AuditNode));
    if (newAudit == NULL) {
        (void)printf("Error: Memory allocation failed for audit entry.\n");
        return;
    }
    ```
  - **Graceful Deallocation:** `freeAllMemory()` traverses all linked list hierarchies:
    1. Traverses and frees all `CustomerNode` instances.
    2. For every `ComplaintNode`, traverses its child `AuditNode` singly linked list, frees every audit event node, and then frees the complaint container node.
    3. Resets `customerHead = NULL` and `complaintHead = NULL`, completely preventing dangling pointer reuse.

### E. Cross-Customer Data Isolation & Access Control (CWE-285)
- **Vulnerability Risk:** In multi-user systems, an authenticated customer must never access or track another customer's complaints.
- **Implemented Protection:**
  - `customerTrackComplaint()` and `customerViewHistory()` enforce an ownership check:
    ```c
    if (strcmp(node->data.customerId, customerId) != 0) {
        (void)printf("Security violation: You are not authorized to view complaints belonging to another customer.\n");
        return;
    }
    ```
  - `customerViewComplaints()` filters strictly on `(strcmp(curr->data.customerId, customerId) == 0)`, rendering unauthorized cross-customer inspection impossible.

### F. File System Safety & Defensive I/O
- **Vulnerability Risk:** Opening missing files or encountering I/O write failures can crash processes or cause silent data truncation.
- **Implemented Protection:**
  - All file streams (`fopen`) verify non-NULL pointers before operations.
  - Missing database files during `initSystem()` trigger automated initial provisioning of the 10 predefined agents and seed counters without error.
  - File handles are deterministically closed using `fclose()` in both success and partial read branches.

### G. Cryptographic Password Hashing & Credential Security (CWE-256, CWE-312, CWE-759, CWE-916)
- **Vulnerability Risk:** Storing plaintext or weakly hashed passwords exposes user accounts to offline dictionary attacks, credential harvesting, and cross-system compromise upon file disclosure.
- **Implemented Protection:**
  - Secure password hashing implemented in `include/security.h` via standard **RFC 8018 PBKDF2-HMAC-SHA256** (with 10,000 iterations), using modular crypt format:
    `$pbkdf2-sha256$i=10000$<salt_hex>$<hash_hex>`
  - Optional support for **Argon2id** via libsodium (`CHS_USE_ARGON2_SODIUM`) where available.
  - Per-record CSPRNG salt generation (16 random bytes from Linux `/dev/urandom` or Windows `CryptGenRandom`).
  - Constant-time comparison (`secure_compare_hashes()`) prevents side-channel timing attacks.
  - Transparent, seamless on-login migration for legacy plaintext records to secure hashes without service disruption.
  - Passwords and hashes are never printed in application logs or standard displays.

---

## 3. Residual Security Observations & Recommendations

| Item | Current Implementation | Production Status |
| :--- | :--- | :--- |
| **Credential Storage** | Passwords hashed with salted **PBKDF2-HMAC-SHA256** (RFC 8018) / **Argon2id** with individual 16-byte random salts. | **RESOLVED & HARDENED** |
| **Legacy Migration** | Transparent migration of legacy plaintext passwords to secure cryptographic hashes upon successful authentication. | **RESOLVED & VERIFIED** |
| **File Permissions** | Files created with standard OS permissions (`0755` directory, `umask` defaults). | In production Linux deployments, restrict database files to mode `0600` owned by a dedicated non-root service account. |
