@echo off
if not exist complaint_system.exe (
    echo Executable not found. Compiling first...
    call build.bat
)
complaint_system.exe
