#!/usr/bin/env bash
set -e

# ==============================================================================
# Linux Coverage Runner for Complaint Handling System Google Test Suite
# ==============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

echo "========================================================================"
echo "      HCL Linux Code Coverage: Complaint Handling System"
echo "========================================================================"

# 1. Verify required Linux coverage tools
REQUIRED_TOOLS=("gcc" "g++" "cmake" "make" "gcov" "gcovr")
for tool in "${REQUIRED_TOOLS[@]}"; do
    if ! command -v "${tool}" >/dev/null 2>&1; then
        echo "[ERROR] Required Linux coverage tool '${tool}' is not installed or not in PATH." >&2
        exit 1
    fi
done

echo "[INFO] GCC version:   $(gcc --version | head -n 1)"
echo "[INFO] GCOV version:  $(gcov --version | head -n 1)"
echo "[INFO] GCOVR version: $(gcovr --version | head -n 1)"

# 2. Prepare coverage output directory
COVERAGE_DIR="${SCRIPT_DIR}/coverage"
mkdir -p "${COVERAGE_DIR}"

# 3. Setup build directory
BUILD_DIR="${SCRIPT_DIR}/build_coverage"
mkdir -p "${BUILD_DIR}"

# 4. Clean stale coverage data safely
echo "[INFO] Cleaning previous coverage artifacts..."
rm -rf "${BUILD_DIR}"/*
rm -rf "${COVERAGE_DIR}"/*
cd "${BUILD_DIR}"

# 5. Configure with coverage enabled
echo "[INFO] Configuring coverage build with CMake..."
cmake "${SCRIPT_DIR}" -DCMAKE_BUILD_TYPE=Debug -DENABLE_COVERAGE=ON

# 6. Build the test executable
echo "[INFO] Compiling instrumented test binary..."
make -j"$(nproc)"

# 7. Run the full test suite to generate execution trace data (.gcda)
echo "========================================================================"
echo "          Executing Full Test Suite with Coverage Instrumentation"
echo "========================================================================"
./run_unit_tests --gtest_color=yes

# 8. Generate coverage reports using gcovr focusing strictly on production src/
echo "========================================================================"
echo "                     Generating Coverage Reports"
echo "========================================================================"

# Filter strictly for production source files (src/) and exclude test files/frameworks
cd "${PROJECT_ROOT}"

# A. Human-readable text summary
gcovr --root . \
      --filter "src/.*" \
      --gcov-ignore-errors=no_working_dir_found \
      --print-summary \
      --txt-metric branch > "${COVERAGE_DIR}/coverage_summary.txt"

cat "${COVERAGE_DIR}/coverage_summary.txt"

# B. Standalone interactive HTML report
gcovr --root . \
      --filter "src/.*" \
      --gcov-ignore-errors=no_working_dir_found \
      --html-details \
      --output "${COVERAGE_DIR}/coverage.html"

# C. Machine-readable Cobertura XML report
gcovr --root . \
      --filter "src/.*" \
      --gcov-ignore-errors=no_working_dir_found \
      --cobertura "${COVERAGE_DIR}/coverage.xml"

# D. Machine-readable JSON report
gcovr --root . \
      --filter "src/.*" \
      --gcov-ignore-errors=no_working_dir_found \
      --json-pretty \
      --output "${COVERAGE_DIR}/coverage.json"

# E. Generate direct annotated gcov source report
MAIN_GCDA="$(find "${BUILD_DIR}" -name "*main.c*.gcda" | head -n 1)"
if [ -n "${MAIN_GCDA}" ]; then
    GCDA_DIR="$(dirname "${MAIN_GCDA}")"
    OBJ_NAME="$(basename "${MAIN_GCDA}" .gcda)"
    (cd "${GCDA_DIR}" && gcov -b -c "${OBJ_NAME}" >/dev/null 2>&1 || true)
    if [ -f "${GCDA_DIR}/main.c.gcov" ]; then
        cp "${GCDA_DIR}/main.c.gcov" "${COVERAGE_DIR}/main.c.gcov"
    fi
fi

echo "========================================================================"
echo " Coverage reports saved successfully to: ${COVERAGE_DIR}/"
echo " - HTML report:    ${COVERAGE_DIR}/coverage.html"
echo " - Summary report: ${COVERAGE_DIR}/coverage_summary.txt"
echo " - Cobertura XML:  ${COVERAGE_DIR}/coverage.xml"
echo " - JSON report:    ${COVERAGE_DIR}/coverage.json"
echo "========================================================================"
